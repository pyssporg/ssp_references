---
id: ADR-014
title: Experimental Fork Is Named experimental_pyssp_standard Everywhere a Name Is Visible
summary: Checkout path and distribution name carry the `experimental_` marker; only the import package stays `pyssp_standard`.
date: 2026-11-04
status: accepted
layers: [architecture, operation]
state: 02-architecture/pipeline-boundaries.md
artifacts:
  - 3rd_party/README.md
  - requirements.txt
  - 3rd_party/pyssp_workflow/3rd_party/experimental_pyssp_standard/pyproject.toml
  - 3rd_party/pyssp_workflow/3rd_party/pyssp_sysml2/pyproject.toml
  - 3rd_party/pyssp_workflow/3rd_party/pyssp_simulate/pyproject.toml
supersedes: []
superseded_by: []
related: [ADR-012]
---

# ADR-013: Experimental Fork Is Named experimental_pyssp_standard Everywhere a Name Is Visible

## Context

ADR-012 moved the checkout to `pyssporg/experimental_pyssp_standard`, but the
checkout directory was still `3rd_party/pyssp_standard`, the distribution was
still `pyssp-standard`, and the version `0.9.2.dev0`. Only the git remote and
prose said "experimental". A reader of a path, a `pip list`, or a wheel name
could not tell the fork from the release line, and a requirement on
`pyssp-standard` resolved silently to the released `pyssporg/pyssp_standard`.

## Decision

Carry the fork name wherever it is visible: checkout path
`3rd_party/experimental_pyssp_standard` (canonical and nested), distribution
`experimental-pyssp-standard`. Import package stays `pyssp_standard`, so no
consumer source changes. Dependents declare the new distribution: `pyssp_sysml2`,
`pyssp_simulate`, `pyssp_vv`, `examples/simple_chain`, and the editable
installs in `requirements.txt` and `requirements-sysml.txt`.

## Rationale

The import name is the expensive surface (hundreds of import sites across every
vendored capability); the directory and distribution names are cheap and are
what actually shows up in paths, `pip list`, and wheel filenames. Marking both
costs two renames per repository and makes the experimental dependency
unmistakable, including to `pip`, which can no longer substitute the release
line for the fork.

## Alternatives Considered

- Rename only the import package: rejected, hundreds of sites across four
  repositories, and no packaging benefit.
- Prose-only disambiguation: rejected as the status quo. Prose does not appear
  in `pip list`, in a path, or in a dependency resolution.
- Keep the distribution name and rely on the git URL pin: rejected. A bare
  `pyssp-standard` requirement still resolves to PyPI.

## Consequences

- Positive: path, dist name, and pin all name the fork; `metadata.version`
  cannot confuse the two libraries.
- Positive: `pip install` fails loudly instead of silently installing the
  release line when the fork is not installed.
- Negative: the fork is not on PyPI, so a PyPI-only install path
  (`pyssp_simulate` CI, `pyssp_sysml2/requirements.txt` before it was repointed
  at the git URL) must install from the git URL or the editable checkout.
- Negative: three repositories need a commit before the pinned gitlinks here
  reflect the new paths.

## Verification

`pb check --strict`. In the repo `venv`,
`metadata.version('experimental-pyssp-standard') == '0.9.2.dev0'` and
`pyssp_standard.__file__` resolves under `.../experimental_pyssp_standard/src/`.
`pytest tests/` in `ssp_references` (164 passed, 1 skipped) and the vendored
library suite (473 passed) stay green after the reinstall.

## Review Trigger

Reopen if the fork is published to PyPI under the experimental name, or if the
fork is merged into the release line and the split stops being real.
