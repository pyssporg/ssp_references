---
id: ADR-015
title: SysML Stack Splits Into Dialect, SSP, and FMI Libraries
summary: One dialect library serves two artifact libraries; pyssp_sysml2 and pyfmi_sysml2 are siblings and never import each other.
date: 2026-11-05
status: accepted
layers: [architecture, implementation]
state: 02-architecture/architecture.md
artifacts:
  - docs/breakdown/03-implementation/sysml-libraries.md
  - 3rd_party/pycps_sysml2/docs/breakdown/03-implementation/module-map.md
  - 3rd_party/pyfmi_sysml2/docs/breakdown/02-architecture/module-map.md
supersedes: []
superseded_by: []
related: [ADR-005, ADR-011, ADR-016, ADR-017]
---

# ADR-015: SysML Stack Splits Into Dialect, SSP, and FMI Libraries

## Context

`pyssp_sysml2` v0.3.0 parsed SysML, resolved parameters, emitted SSP-family
artifacts, and generated FMI. One package owned three concerns with different
consumers and release rhythms, and the FMI half had no SSP consumer.

## Decision

Split the stack into three libraries. `pycps_sysml2` owns the dialect;
`pyssp_sysml2` owns SSP-family emission and SSD→SysML synthesis;
`pyfmi_sysml2` owns FMI 2.0 CoSimulation artifacts. The two artifact libraries
are siblings over `pyssp_standard`: neither imports the other.

## Rationale

FMI consumers need the dialect without SSP packaging, and SSP consumers need it
without FMI. One package forced both to carry the other's release surface, and
made an FMI change an SSP release.

## Alternatives Considered

- Keep one package with optional extras: rejected, releases still coupled and imports stay entangled.
- Split FMI only, leaving dialect in `pyssp_sysml2`: rejected, FMI would depend on the SSP implementer.

## Consequences

- Positive: each library has one artifact contract and one release line.
- Positive: a consumer installs only the producer it needs.
- Negative: three repositories, three pins, and a gitlink order to keep.
- Negative: `pyssp_sysml2` keeps v0.4.x re-export shims until v0.5.0.

## Verification

`pb check --strict`; the module maps show the one-way import graph; the build
suite runs both artifact paths. Documentation unit U4.3 records the split in
`INFO-002` and `INFO-012`.

## Review Trigger

Reopen if an artifact library needs a type from the other, or if one release
line must ship both artifact families together.
