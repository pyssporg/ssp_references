---
id: ADR-016
title: pycps_sysml2 Owns the SysML Dialect for Both Artifact Libraries
summary: Variation, constraint, and parameter semantics for the SSP and FMI dialects live in pycps_sysml2, whose only runtime dependency is sysmlpy.
date: 2026-11-05
status: accepted
layers: [architecture, implementation]
state: 03-implementation/sysml-libraries.md
artifacts:
  - 3rd_party/pycps_sysml2/pyproject.toml
  - 3rd_party/pycps_sysml2/docs/breakdown/03-implementation/module-map.md
  - 3rd_party/pyssp_workflow/3rd_party/pyssp_sysml2/pyproject.toml
supersedes: []
superseded_by: []
related: [ADR-015, ADR-009]
---

# ADR-016: pycps_sysml2 Owns the SysML Dialect for Both Artifact Libraries

## Context

Markers, parameter semantics, variation selection, and constraint evaluation
were implemented in `pyssp_sysml2` but are not SSP-specific: an FMI model needs
the same component, port, and parameter facts. Keeping them there would force
`pyfmi_sysml2` to import the SSP implementer or copy the rules.

## Decision

`pycps_sysml2` owns the dialect for both SSP and FMI: parsing, IR, markers,
parameters, variation, configuration, selection, and constraints.
`sysmlpy==0.96.4` is its only runtime dependency; the artifact libraries pin it
and add `pyssp_standard`.

## Rationale

A dialect copy per artifact library drifts. One home makes a grammar bump one
decision and keeps both artifact libraries reading the same facts.

## Alternatives Considered

- Leave the dialect in `pyssp_sysml2` and have `pyfmi_sysml2` depend on it: rejected, couples FMI releases to SSP releases.
- Duplicate the dialect per artifact library: rejected, two truths for markers and variation.

## Consequences

- Positive: one grammar pin and one marker vocabulary for both dialects.
- Positive: `pyssp_sysml2` and `pyfmi_sysml2` depend on a library neither owns.
- Negative: `pyssp_sysml2.model`, `.core`, `.metadata`, and `.parameters` are re-export shims in v0.4.x, removed in v0.5.0.
- Negative: a dialect change is a three-repository pin bump.

## Verification

`pb check --strict`; `pycps_sysml2` metadata lists only `sysmlpy==0.96.4`;
`tests/test_legacy_sysml_shims.py` exercises the v0.4.x shims. Documentation
unit U4.3 records the rule in `INFO-012`.

## Review Trigger

Reopen if an artifact library needs a dialect fact the shared IR cannot carry,
or if the shims outlive v0.5.0.
