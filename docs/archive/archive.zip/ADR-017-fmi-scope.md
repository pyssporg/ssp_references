---
id: ADR-017
title: FMI 2.0 Co-Simulation Only, Linux x86-64 Only
summary: The FMI implementer emits FMI 2.0 co-simulation artifacts for 64-bit Linux; Model Exchange and FMI 3.0 stay out of scope.
date: 2026-11-05
status: accepted
layers: [product, architecture]
state: 01-product/contract.md
artifacts:
  - docs/breakdown/01-product/contract.md
  - 3rd_party/pyfmi_sysml2/docs/breakdown/06-evolution/roadmap.md
supersedes: []
superseded_by: []
related: [ADR-015, ADR-016]
---

# ADR-017: FMI 2.0 Co-Simulation Only, Linux x86-64 Only

## Context

The fixtures run co-simulation SSPs. FMI 2.0 defines both Model Exchange and
Co-Simulation, FMI 3.0 adds a new schema, and binary artifacts are
platform-specific with only `linux64` built here. Each extra mode multiplies
runtime and packaging surface.

## Decision

The FMI implementer emits FMI 2.0 Co-Simulation artifacts only, for `linux64`
binaries. Model Exchange, FMI 3.0, and other platforms are out of scope; plan
decisions D2, D4, and D12 fix these bounds.

## Rationale

Co-simulation is the mode SSP uses and both backends execute. Model Exchange
and FMI 3.0 have no fixture consumer yet, so supporting them would add code
without a comparison that can judge it.

## Alternatives Considered

- Add Model Exchange with 2.0: rejected, needs solver and runtime work no fixture exercises.
- Target FMI 3.0 first: rejected, SSP tooling and the fixtures are FMI 2.0.

## Consequences

- Positive: one schema, one interface type, one package layout to verify.
- Positive: the scope fits the fixtures and the installed backends.
- Negative: non-`linux64` users cannot consume the packaged FMU.
- Negative: Model Exchange and FMI 3.0 need a later decision before any code.

## Verification

`pb check --strict`; `pyfmi_sysml2` packaging rejects an unknown platform, and
the shipped fixture runs under the co-simulation backends. Documentation unit
U4.3 records the bound in `CP-001` and `INFO-012`.

## Review Trigger

Reopen when a fixture needs Model Exchange, an FMI 3.0 consumer appears, or a
supported platform is added.
