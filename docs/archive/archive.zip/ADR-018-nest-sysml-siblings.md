---
id: ADR-018
type: architecture-decision
title: Nest the SysML Siblings Under the Workflow Install Bundle
summary: One submodule and one install bundle pin the stack; pyssp_workflow nests all seven checkouts and imports none of them.
date: 2026-11-05
status: accepted
layers: [architecture, operation]
state: 02-architecture/pipeline-boundaries.md
artifacts:
  - 3rd_party/README.md
  - docs/breakdown/03-implementation/sysml-libraries.md
  - docs/breakdown/05-operation/install-model.md
  - docs/breakdown/04-verification/pyssp_project_verification_plan.md
supersedes: []
superseded_by: []
related: [ADR-015, ADR-016]
---

# ADR-018: Nest the SysML Siblings Under the Workflow Install Bundle

## Context

The split (`ADR-015`) left `pycps_sysml2` and `pyfmi_sysml2` as repo-level
submodules beside `pyssp_workflow`. That placement lived only as prose in
`3rd_party/README.md`; no archived record stated it. Three gitlinks, three init
steps, and a second install path tracked one stack.

## Decision

On 2026-11-05, one install bundle and one submodule pinned the stack.
`requirements.txt` carries a single `pyssp-workflow[sysml,flow]` reference whose
metadata pins all eight distributions. `pyssp_workflow` nests all seven
checkouts and imports none of them; its `sysml` extra only installs them.
Dev editables point into `3rd_party/pyssp_workflow/3rd_party/`.

## Rationale

One pin to bump and one submodule to initialize replaces three. Consumers get
the whole stack from one resolution step, and a SysML library release no longer
costs a superproject gitlink.

## Alternatives Considered

- Keep repo-level SysML submodules: rejected, three pins for one stack and a second install path.
- Drop the SysML libraries from the bundle: rejected, the build and authoring stages need both every run.

## Consequences

- Positive: one `git submodule update --init --recursive`, one version record.
- Negative: `pyssp_workflow`'s `.gitmodules` grows to seven entries.
- Negative: `pycps_sysml2` is pinned by two libraries, not three, so its gitlink lives in two places inside the tree.

## Verification

`pb check --strict`; `git submodule status --recursive` shows one top-level
gitlink; the install model and boundary table name the nested paths.

## Review Trigger

Reopen if a consumer needs one SysML library without the capability tree, or if
an artifact library must release outside the workflow bundle.
