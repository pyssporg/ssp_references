---
id: ADR-019
title: Dialect Core Definitions Are Packaged by pycps_sysml2
summary: The dialect markers and metadata schemas are declared once in pycps_sysml2's packaged core; a model loads it as one include root beside its own architecture roots.
date: 2026-11-05
status: accepted
layers: [architecture, implementation]
state: 02-architecture/architecture.md
artifacts:
  - 3rd_party/pyssp_workflow/3rd_party/pycps_sysml2/src/pycps_sysml2/definitions/core.sysml
  - 3rd_party/pyssp_workflow/3rd_party/pycps_sysml2/tests/test_core_definitions.py
  - tests/test_fmu_artifacts.py
supersedes: [ADR-009]
superseded_by: []
related: [ADR-009, ADR-016, PD-004]
---

# ADR-019: Dialect Core Definitions Are Packaged by pycps_sysml2

## Context

`ADR-009` required explicit marker definitions in the same package as the
composition. Every fixture then copied the seven definitions, and the copies
could drift. `ADR-016` made `pycps_sysml2` the dialect owner, so the shared
vocabulary needed one packaged home. The loader now accepts any number of
architecture roots, which makes an included definition root the general
mechanism. This record replaces only `ADR-009`'s same-package declaration
clause; its explicit-marker rule stands.

## Decision

Declare the seven dialect markers and metadata schemas once in `pycps_sysml2`'s packaged `definitions/core.sysml` (`package PysspCore`).
`load(path, *includes)` takes any number of roots: the first is the model.
Later sequence elements and `*includes` are included roots: files or folders, any package name, excluded from `export_declared()`.
A local redeclaration of an included definition is an error.
The packaged core is one include: `load(dir, core_definitions())`, `includes=()` on the generators and `pyssp_workflow.authoring`.
`--architecture` repeats (model first); `--core-definitions` adds the core include. Markers stay explicit.

## Rationale

Seven definitions copied into every architecture hide the dialect contract, let
fixtures diverge silently, and make a marker change an edit in each model. One
included root keeps the vocabulary explicit and reviewable, and the duplicate
rule makes a divergent copy fail loudly instead of merging silently.

## Alternatives Considered

- Keep per-model declarations: rejected, the copies drift and the contract is invisible.
- Implicit markers inferred from structure: rejected in `ADR-009`, the generator cannot see them.
- A build-time include without loader support: rejected, it creates a second merge path beside the IR.
- A dedicated `library=` loader argument: rejected, it special-cases one include root beside the general mechanism.

## Consequences

- Positive: fixtures stop redeclaring core definitions; the dialect has one source.
- Positive: included roots are ordinary architecture roots; no second loading path exists.
- Positive: opt-in keeps a model that supplies its own definitions loading unchanged.
- Negative: every consumer names the core include (or passes the CLI flag).
- Negative: the core file must ship as package data.

## Verification

`pycps_sysml2`'s `tests/test_core_definitions.py` covers package data, multi-root
loading, duplicate rejection, and export exclusion; root
`tests/test_fmu_artifacts.py` forbids redeclaration in the fixtures; `pb check
--strict` gates the docs.

## Review Trigger

Reopen if a second dialect needs a different core vocabulary, or if the core
file and a released implementer must diverge.
