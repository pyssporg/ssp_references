---
id: DD-013
title: Generic Engine, Build, Comparison, and Figure Code Lives in the pyssp Dependencies
summary: Engine, packaging, comparison, figure, and authoring code lives upstream; this repository keeps layout, registry, gate, and fixtures.
date: 2026-10-23
status: accepted
layers: [implementation]
state: 03-implementation/workflow.md
artifacts:
  - scripts/workflow/simulate.py
  - scripts/workflow/comparison.py
  - scripts/generate_comparative_plots.py
  - 3rd_party/pyssp_workflow/src/pyssp_workflow/execute/__init__.py
  - 3rd_party/pyssp_workflow/3rd_party/pyssp_simulate/src/pyssp_simulate/spec.py
  - 3rd_party/pyssp_workflow/3rd_party/pyssp_vv/src/pyssp_vv/measure/figures.py
supersedes: []
superseded_by: []
related: [ADR-005, ADR-008, DD-010, PD-005]
---

# DD-013: Generic Engine, Build, Comparison, and Figure Code Lives in the pyssp Dependencies

## Context

Five units of generic code duplicated capabilities the dependencies already
owned: engine workarounds, SSP packaging forms, comparison plumbing, figure
rendering, and build authoring glue. The local copies drifted from the
dependencies they wrapped and kept engine quirks inside this repository.

## Decision

Deleted the local copies and moved the behavior upstream: `pyssp_simulate`,
`pyssp_workflow.execute`, `pyssp_workflow.params`, `pyssp_vv.evidence`,
`pyssp_vv.measure`, and `pyssp_workflow.authoring`. Each dependency gitlink was
bumped.

The figure renderer lives in `pyssp_vv.measure.figures`, which imports
matplotlib inside `render_figure`.

FMPy applies only the parameter set declared in the SSD; an SSV the system
definition does not reference is never merged.

## Rationale

Generic code belongs to the capability that owns it. Keeping a copy here
duplicated behavior and hid engine gaps. A function-local matplotlib import
keeps `measure` importable without the figures extra. Applying only the
declared parameter set keeps the built SSP the complete engine input.

## Alternatives Considered

- Keep the local shims and wait for upstream. Rejected: the gaps were already
  closed upstream, and two copies drift.
- Merge any SSV found beside the SSP for FMPy. Rejected: it invents parameter
  data the system definition does not reference.

## Consequences

- Positive: one implementation per capability; dependency bumps carry the
  behavior.
- Negative: this repository follows dependency revisions; a regression must be
  fixed upstream and the gitlink bumped.

## Verification

Verification is the registered simulate-then-compare matrix, which exercises
every delegating path (`EVAL-001`). No separate check was added for the
migration.

## Review Trigger

Revisit if a dependency cannot carry a change this repository needs, or if a
local copy becomes necessary again.
