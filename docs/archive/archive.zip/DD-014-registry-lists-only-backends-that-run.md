---
id: DD-014
title: Registry Lists Only Backends That Run the Case
summary: A case's backends name the engines that can simulate it; an engine that cannot run the case is not listed.
date: 2026-10-29
status: accepted
layers: [implementation]
state: 04-verification/simulation_registry_coverage_review.md
artifacts:
  - artifacts/simulation_registry.json
  - models/ssp/signal_parameter_inline_with_mapping/FIXTURE.md
supersedes: []
superseded_by: []
related: [DD-005, DD-011, PD-002]
---

# DD-014: Registry Lists Only Backends That Run the Case

## Context

The artifact rebuild re-ran every registered case. OMSimulator crashed on
`signal_parameter_inline_with_mapping/baseline`: inline `ParameterValues` plus a
`ParameterMapping` made its parser look for `ssm:ParameterMapping` inside
`ssd:ParameterMapping`, find nothing, and fail. Probed shapes: schema-flat and
nested. Both fail; OMSimulator also applies inline values at the root scope
under the raw SSV name, ignoring the mapping.

## Decision

Dropped `omsimulator` from that case's backends on 2026-10-29; `ssp4sim` applies
inline values and the mapping correctly. Re-register the backend when OMSimulator
supports inline values with a mapping. The emitted SSD shape stays as-is: it is
schema-valid, and both the XSD and ssp4sim accept it.

## Rationale

PD-002: the registry is the single source of truth. A backend listed for a case
must run it. With one engine there is no cross-engine gate; the fixture page
documents the limitation instead.

## Alternatives Considered

- Fix `pyssp_standard`. Rejected: the emitted shape is schema-valid; nothing to fix.
- Keep `omsimulator` listed. Rejected: every registered case must run; the claim was false.

## Consequences

- Positive: registry honest, simulations run green end to end.
- Negative: the case no longer demonstrates inline values plus mapping through a
  two-engine gate; `FIXTURE.md` states the limitation.

## Verification

`scripts/run_simulations.py` runs every registered case green; the artifact
corpus test checks registry and artifact agreement.

## Review Trigger

OMSimulator gains inline `ParameterValues` plus `ParameterMapping` support.
