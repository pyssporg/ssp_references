---
id: DD-015
title: Registry Application — Pass-Through OMSimulator Drop
summary: Per DD-014, an engine that cannot run the case is not listed for the case.
date: 2026-10-29
status: accepted
layers: [implementation]
state: 04-verification/simulation_registry_coverage_review.md
artifacts:
  - artifacts/simulation_registry.json
  - models/ssp/signal_nested_pass_through/FIXTURE.md
supersedes: []
superseded_by: []
related: [DD-014, DD-005, PD-002]
---

# DD-015: Registry Application — Pass-Through OMSimulator Drop

## Context

Applying DD-014 to a second case on 2026-10-29. The rebuilt
`signal_nested_pass_through/baseline` SSP differs from the stale committed one only
in the generator-emitted inline SSV set names (`parameters` per component scope
instead of `step_parameters`/`add_parameters`/`gain_parameters`). OMSimulator
fails to instantiate those bytes: duplicate root-scope connector `model.root.y`.
HEAD's bytes instantiate fine. ssp4sim simulates the rebuilt bytes.

## Decision

Dropped `omsimulator` from `signal_nested_pass_through/baseline`; `ssp4sim`
stays. Removed the stale OMSimulator outputs and the invalid-gate comparison.
Re-register the backend when OMSimulator can instantiate the stack's emitted
content.

## Rationale

The registry must not claim a backend that cannot run the case. The emitted
SSD shape is schema-valid and not pinned by the fixture; the engine quirk is the
blocker.

## Alternatives Considered

- Restore per-component SSV set names in the vendored stack. Rejected: the
  emitted name is schema-valid, and the two-engine gate is red anyway on
  pre-existing criterion failures.

## Consequences

- Positive: registry honest; the case runs green on its registered backend.
- Negative: the case no longer judges OMSimulator; `FIXTURE.md` states the
  limitation.

## Verification

`scripts/run_simulations.py` runs every registered case green; the corpus test
checks registry and artifact agreement.

## Review Trigger

OMSimulator can instantiate the stack's emitted content again.
