---
id: DD-016
title: Registry Application — Pass-Through OMSimulator Drop
summary: Per DD-014, an engine that cannot run the case is not listed for the case.
date: 2026-10-29
status: accepted
layers: [implementation]
state: 04-verification/simulation_registry_coverage_review.md
artifacts:
  - artifacts/simulation_registry.json
  - models/ssp/signal_nested_external_bindings/FIXTURE.md
supersedes: []
superseded_by: []
related: [DD-014, DD-015, DD-005, PD-002]
---

# DD-016: Registry Application — Pass-Through OMSimulator Drop

## Context

Applying DD-014 to a third case on 2026-10-29. OMSimulator fails to instantiate
the rebuilt `signal_nested_external_bindings/baseline` SSP with the same
duplicate root-scope connector (`model.root.y`) it hits on
`signal_nested_pass_through/baseline`. Both stale cases' committed outputs came
from older generator eras. ssp4sim simulates both rebuilt cases.

## Decision

Dropped `omsimulator` from `signal_nested_external_bindings/baseline`; `ssp4sim`
stays. Removed the stale partial outputs. Re-register the backend when
OMSimulator can instantiate the stack's emitted content.

## Rationale

Same defect family as DD-015; the registry must reflect what each engine can
run, per PD-002.

## Alternatives Considered

- Fix the OMSimulator parser. Rejected: the emitted shape is schema-valid; the
  failure is in the engine's System construction.

## Consequences

- Positive: registry honest; both nested-System cases run green on their
  registered backend.
- Negative: the cases no longer judge OMSimulator; `FIXTURE.md` states the
  limitation.

## Verification

`scripts/run_simulations.py` runs every registered case green; the corpus test
checks registry and artifact agreement.

## Review Trigger

OMSimulator gains support for the emitted nested-system shape.
