---
id: DD-017
title: Large Fixture Architectures Split Along Section Boundaries
summary: Fixture SysML above roughly 100 lines is split into five section files that share one package; the loader merges them in file-name order.
date: 2026-10-30
status: accepted
layers: [implementation]
state: 03-implementation/FIXTURE-template.md
artifacts:
  - models/ssp
  - tests/test_variation_cases.py
  - docs/breakdown/02-architecture/architecture.md
  - docs/breakdown/03-implementation/FIXTURE-template.md
supersedes: []
superseded_by: []
related: [PD-004]
---

# DD-017: Large Fixture Architectures Split Along Section Boundaries

## Context

Fixture architectures repeated one section order: role markers and ports,
parameter sets, FMU metadata and components, the top composition with its
variation points and constraints, then analyses. The largest grew past 200
lines in one file, so those sections were no longer visible.

`pyssp_sysml2` already loads a directory of `*.sysml` files: it parses each
file separately, merges them in sorted name order, and keeps per-definition
`source_file`, so export and sync preserve the layout. The repository was not
using that capability.

## Decision

Fixture SysML above roughly 100 lines splits along its existing sections:
`01-interfaces` (markers, ports), `02-parameters` (sets, experiments),
`03-components` (FMU metadata, components, nested systems), `04-structure`
(variation points, constraints, composition, configurations), `05-analyses`.
Every file repeats the package; numeric prefixes keep merge and analysis order
stable. Smaller fixtures stay in one file.

## Rationale

The boundaries match the concepts an author navigates by and the sections the
single files already used. Prefix order reproduces declaration order, so a
split changes no derived selection, SSD, SSP, or analysis. Leaving small
fixtures whole avoids five near-empty files around a thirty-line model.

## Alternatives Considered

- Split every fixture. Rejected: fragments small models without improving navigation.
- Keep one file with section comments. Rejected: comments do not bound the file.
- Unprefixed file names. Rejected: alphabetical load order puts analyses first.

## Consequences

- Positive: each file is short and single-purpose; the loader treats the split
  exactly like the old single file.
- Positive: `sync ssd` preserves the split through `source_file`.
- Neutral: a split fixture's `FIXTURE.md` lists the file set instead of one path.
- Negative: a definition is no longer found by opening one file; navigation
  relies on the section names.

## Verification

For every split fixture, loading the directory yields the same architecture
(minus `source_file`), the same analysis plans and selection partition, and a
byte-identical generated SSD. `pytest tests/` covers the regenerated wiring,
the variation cases, and the constraint-source check.

## Review Trigger

A fixture architecture outgrows a section file, or the loader stops accepting
multi-file layouts.
