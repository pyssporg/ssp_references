---
id: DD-018
title: Fixture Layout — Model Definition, System, Build Artifact
summary: A SysML-authored FMU keeps its generated definition in models/fmu/, its system in models/ssp/, and every compiled or packaged output under artifacts/build/.
date: 2026-11-05
status: accepted
layers: [implementation]
state: 02-architecture/architecture.md
artifacts:
  - models/ssp/GainOffset
  - models/fmu/GainOffset
  - artifacts/build
  - tests/test_fmu_artifacts.py
  - docs/breakdown/02-architecture/architecture.md
  - docs/breakdown/03-implementation/workflow.md
supersedes: []
superseded_by: []
related: [PD-004, DD-017]
---

# DD-018: Fixture Layout — Model Definition, System, Build Artifact

## Context

`GainOffset` was the only fixture whose `build.py` lived under `models/fmu/`.
That directory held both the generated FMU definition and the compiled and
packaged products, so `models/` mixed authored with generated state and the
build wrote a binary into the tree it read the interface from. Two fixture
roots also meant two discovery rules in `scripts/build_models.py`.

## Decision

Split a SysML-authored FMU by role: `models/fmu/<model>/` keeps only the
definition (`src/`, `include/`, generated `fmu/modelDescription.xml` and
`fmu/sources/*.h`); `models/ssp/<model>/` keeps `architecture/`, `build.py`,
`references/`, and `FIXTURE.md`; `artifacts/build/<model>/` keeps every compiled
or packaged output (`Generator.so`, `Generator.fmu`) and is committed because
the SSP build embeds the archive. `FmuMetadata.source` points at the artifact.

## Rationale

The build contract is easier to verify when generated text, compiled output,
and the system that embeds them have one home each. One fixture root also
removes the name and artifact-path collision between the two discovery rules.

## Alternatives Considered

- Keep one `models/fmu/GainOffset/` tree with `binaries/` and `build.py`.
  Rejected: it mixes model and artifact and keeps the second discovery rule.
- Leave the archive in an ignored `build/` directory. Rejected: a fresh clone
  could not export the SSP without a compiler.

## Consequences

- Positive: `models/` holds only authored and committed definition text;
  `artifacts/build/<model>/` is the single home for compiled output.
- Negative: the packaged archive is committed, so a compiler upgrade changes
  tracked bytes; `.gitignore` needs an exception for `artifacts/build/`.

## Verification

`tests/test_fmu_artifacts.py` checks definition, binary, and archive against
each other; two consecutive `build_models.py run GainOffset` produce an
identical definition tree and archive hash; `run-all`, the test suite, and the
`GainOffset` reference comparison pass.

## Review Trigger

A second SysML-authored FMU adopts the split, or the archive stops being an
input to the SSP build.
