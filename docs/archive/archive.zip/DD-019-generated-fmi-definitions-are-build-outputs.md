---
id: DD-019
title: Generated FMI Definitions Are Build Outputs
summary: Generated FMI definitions live under artifacts/build/; models/fmu keeps authored sources and the committed archive carries the definition.
date: 2026-11-05
status: accepted
layers: [implementation]
state: 02-architecture/architecture.md
artifacts:
  - models/fmu/GainOffset
  - models/ssp/GainOffset/build.py
  - artifacts/build
  - tests/test_fmu_artifacts.py
  - docs/breakdown/02-architecture/architecture.md
  - docs/breakdown/03-implementation/workflow.md
supersedes: [DD-018]
superseded_by: []
related: [PD-004, DD-017]
---

# DD-019: Generated FMI Definitions Are Build Outputs

## Context
DD-018 split a SysML-authored FMU by role but left generated definition text
(`fmu/modelDescription.xml`, `fmu/sources/*.h`) inside `models/fmu/<model>/`.
Each build rewrote tracked generated files in the tree it read the interface
from, so a rebuild dirtied `models/` and a checkout carried half-generated
state.

## Decision
Generated FMI definitions — C interface headers and `modelDescription.xml` —
became build outputs under `artifacts/build/<model>/`. `models/fmu/<model>/`
kept authored sources and provenance only. The committed `.fmu` archive
carried the definition for consumers. This amended DD-018 on that point only;
its role split stood.

## Rationale
Authored and generated state must not share a tree: a rebuild either dirties
`models/` or silently reuses stale generated text. One generator run per
build, with the archive as the committed definition copy, keeps the fixture
reproducible from a fresh clone without a compiler.

## Alternatives Considered
- Keep `fmu/` in the fixture tree as committed generated text. Rejected:
  rebuilds churn tracked files and duplicate the archive.
- Generate into an ignored scratch directory only. Rejected: consumers had no
  committed definition to read.

## Consequences
- Positive: `models/fmu/<model>/` holds authored inputs only; generated text
  has one home per build.
- Negative: definition text is read from the archive unless a build has run.

## Verification
`tests/test_fmu_artifacts.py` reads `modelDescription.xml` and the C headers
from the committed archive and checks them against the binary; two builds
produce an identical definition set and archive hash.

## Review Trigger
A consumer needs definition text outside the `.fmu` archive, or the build stops
writing generated definitions into `artifacts/build/`.
