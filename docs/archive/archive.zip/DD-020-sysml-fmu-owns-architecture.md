---
id: DD-020
title: SysML-Authored FMU Owns Its Architecture; Build Runs FMU Before SSP
summary: FMU architecture holds only FMU definitions; the system fixture owns System/Analysis and links the FMU file; the build runs FMU before SSP.
date: 2026-11-05
status: superseded
layers: [implementation]
state: 02-architecture/architecture.md
artifacts:
  - models/fmu/GainOffset
  - models/ssp/GainOffset
  - models/ssp/GainOffset/architecture/System.sysml
  - scripts/build_models.py
  - artifacts/build
  - tests/test_fmu_artifacts.py
  - docs/breakdown/02-architecture/architecture.md
  - docs/breakdown/03-implementation/workflow.md
supersedes: [DD-018]
superseded_by: [DD-021]
related: [PD-004, DD-017, DD-019]
---

# DD-020: SysML-Authored FMU Owns Its Architecture; Build Runs FMU Before SSP

## Context

DD-018 gave the definition to `models/fmu/<model>/` and the architecture to `models/ssp/<model>/`; DD-019 moved generated definition text out of the tree.
Once the FMU needed its own SysML input, one shared architecture mixed the FMU interface with the consumer's system and analysis definitions.
The FMU could not be built or read without the system that embeds it.
One shared build phase could not express "compile the FMU, then export the SSP".

## Decision

A SysML-authored FMU owns only its FMU definitions — ports, metadata, component, and `Fmu` composition root — under `models/fmu/<model>/architecture/`.
The system fixture owns `System`/`Analysis` in `models/ssp/<model>/architecture/System.sysml` and links the canonical FMU *file* with a relative symlink (`<model>.sysml -> ../../../fmu/<model>/architecture/<model>.sysml`).
`Fmu` is a one-part root because `pyfmi_sysml2` exports components below a composition root.
The FMU build calls `generate_c_headers`/`generate_model_description` with `composition="Fmu"`; the SSP build derives the SSP from `System`.
`build_models.py` runs the FMU phase before the SSP phase; one model name may appear in both roots.
Generated definition text stays build output under `artifacts/build/<model>/` (DD-019).

## Rationale

The FMU interface is the FMU's authored input, so it belongs with the FMU source; `System` and `Analysis` describe the embedding fixture and stay with it.
A file link keeps one authored copy of the FMU definitions while the system directory still resolves each file.
`pyfmi_sysml2` exports components below a composition root, so the FMU needs `Fmu` even with one component.
A separate FMU phase states the real dependency (the SSP embeds the archive) and lets `run-all` build every FMU before any SSP.

## Alternatives Considered

- Keep the whole architecture in `models/ssp/<model>/` and let the FMU build reach across roots. Rejected: reverses ownership and couples the FMU to a consumer.
- Link the whole architecture directory. Rejected: the system file would live in the FMU's tree, re-mixing the FMU and system definitions.
- Copy the FMU definitions into both roots. Rejected: two authored copies drift.

## Consequences

- Positive: one authored FMU definition set per FMU; system composition and analyses have one home; the build order matches the artifact dependency.
- Negative: the system architecture depends on a relative file link, so a tool that does not follow file symlinks cannot resolve the FMU definitions from `models/ssp/<model>/architecture/`.

## Verification

`tests/test_fmu_artifacts.py` reads the FMU inputs, the linked architecture, and the committed archive; `build_models.py run GainOffset` builds FMU then SSP, and `run-all` builds every FMU before any SSP.
A rebuild reproduces `modelName="Fmu.Generator"`, the definition tree, and the archive hash (`Generator.fmu` sha256 `3167ed08f91fef3b45a4fa036f58bef63b0a2c66428dff003640c33c3ccfd97b`).

## Review Trigger

A second SysML-authored FMU adopts the layout, or a tool cannot follow the architecture file symlink.
