---
id: DD-021
title: FMU Marker Replaces the Composition Root; the System Includes the FMU Architecture
summary: An FMU declares its component with the `FmuModel` marker, its definition name is the exported identity, and the system build includes the FMU architecture.
date: 2026-11-05
status: accepted
layers: [architecture, implementation]
state: 02-architecture/architecture.md
artifacts:
  - models/fmu/GainOffset
  - models/ssp/GainOffset
  - models/fmu/GainOffset/build.py
  - models/ssp/GainOffset/build.py
  - artifacts/build
  - docs/breakdown/02-architecture/architecture.md
  - docs/breakdown/03-implementation/workflow.md
supersedes: [DD-020]
superseded_by: []
related: [DD-019, PD-004, ADR-019]
---

# DD-021: FMU Marker Replaces the Composition Root; the System Includes the FMU Architecture

## Context
DD-020 kept a one-part `Fmu` composition root because `pyfmi_sysml2` exported components below a composition root, and projected the canonical FMU file into the system tree with a relative symlink.
The root named a wrapper that is not part of the model.
The symlink made one file appear in two ownership domains and failed for tools that do not follow file links.

## Decision
A SysML-authored FMU declares its component directly with the `FmuModel` marker (`part def Generator :> FmuModel { attribute fmu_meta : GeneratorFmu; ... }`); the `Fmu` composition root was removed.
`pycps_sysml2` core owns `FmuModel`, so the dialect alone defines how an FMU is declared.
The exported identity is the definition name: `modelName="Generator"` and guid `uuid5(NAMESPACE_URL, "pyssp_sysml2/Generator")`.
The system build consumes the canonical FMU architecture directory through `build_fixture(includes=...)`; the per-system `<model>.sysml` symlink was removed.

## Rationale
The split between `models/fmu/` and `models/ssp/` follows the logical model/system line: the FMU package owns its complete definition and is discoverable by marker; the system owns `System`/`Analysis`.
A marker on the definition needs no wrapper part and leaves the definition name as the only exported name.
An include names a build input directory; it does not project a second path to the same file.

## Alternatives Considered
- Keep the `Fmu` root and add `FmuModel` beside it. Rejected: two ways to declare an FMU.
- Copy the FMU architecture into `models/ssp/<model>/architecture/`. Rejected: two authored copies drift.
- Keep the relative symlink. Rejected: it projects a file into the consumer tree and fails for tools that do not resolve links.

## Consequences
- Positive: one marker per FMU; the definition is complete in `models/fmu/<model>/` and the system references it by directory.
- Negative: the exported identity changed (`modelName` was `"Fmu.Generator"` and the guid followed that name), so committed archives and comparison baselines must be rebuilt and re-pinned from the build output.

## Verification
`build_models.py run GainOffset` builds the FMU then the SSP, and `tests/test_fmu_artifacts.py` checks the exported identity, the include root, and the archive contents.
A rebuild reproduces `modelName="Generator"`, the definition tree, and the archive hash; the pin comes from the build output.

## Review Trigger
A second SysML-authored FMU adopts the marker, or an exporter needs a composition root again.
