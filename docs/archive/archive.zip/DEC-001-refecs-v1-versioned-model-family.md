---
id: DEC-001
title: Versioned RefECS Family — `embrace` Becomes `refecs_v1`
summary: The SSP fixture `models/ssp/embrace` is `models/ssp/refecs_v1`, the first version in a family where each version registers as a separate model and test.
date: 2026-11-19
status: accepted
layers: [architecture, verification]
state: 04-verification/co_simulation_fixture_mapping.md
artifacts:
  - models/ssp/refecs_v1
  - models/ssp/refecs_v1/architecture/01-interfaces.sysml
  - models/ssp/refecs_v1/architecture/02-parameters.sysml
  - models/ssp/refecs_v1/architecture/03-components.sysml
  - models/ssp/refecs_v1/architecture/04-structure.sysml
  - models/ssp/refecs_v1/architecture/05-analyses.sysml
  - models/ssp/refecs_v1/build.py
  - models/ssp/refecs_v1/FIXTURE.md
  - models/README.md
  - tests/test_sysml_fixtures.py
  - artifacts/simulation_registry.json
  - docs/breakdown/04-verification/co_simulation_fixture_mapping.md
  - docs/breakdown/04-verification/co_simulation_test_strategy.md
  - docs/breakdown/04-verification/ecosystem_adoption_assessment.md
  - docs/breakdown/04-verification/simulation_registry_coverage_review.md
  - docs/breakdown/05-operation/results-interpretation.md
  - docs/breakdown/06-evolution/selected/scenario-ownership-strategy-for-ssp-fixtures.md
supersedes: []
superseded_by: []
related: [PD-004, DD-017]
---

# DEC-001: Versioned RefECS Family — `embrace` Becomes `refecs_v1`

## Context
The composite SSP fixture `models/ssp/embrace` carried the name of the legacy
EMBRACE example it was derived from, with no place for a second version.
A future `refecs_v2` is planned as a sibling model, and both versions must be
registered and exercised side by side rather than replacing one another.
The pre-rename run artifacts under `artifacts/{simulation,comparisons,plots}/embrace/`
are historical evidence and are not regenerated under a new name.

## Decision
On 2026-11-19 the fixture is renamed from `models/ssp/embrace` to `models/ssp/refecs_v1`,
"Reference Environmental Control System (RefECS), version 1", with SysML package `RefecsV1`
and registry key `refecs_v1`; no alias or symlink keeps the old `embrace` name.
The five `architecture/*.sysml` files, `build.py`, `FIXTURE.md`, `models/README.md`,
the `EXPECTED` key in `tests/test_sysml_fixtures.py`, and `artifacts/simulation_registry.json`
are updated to the new name, and the breakdown leaves that cited the fixture follow.

## Rationale
A versioned family lets `refecs_v1` and `refecs_v2` exist as separate registry
models with separate build, simulation, and comparison outputs, so results from
one version never overwrite the other.
Registering each version as its own model also gives each its own test entry,
which keeps the two versions independently gated.
An alias would keep a second live name for the same fixture and blur which name
the registry, tests, and archives own.

## Alternatives Considered
- Keep `embrace` and add `refecs_v2` beside it. Rejected: unversioned and versioned siblings imply different relationships between the two fixtures.
- Rename to `refecs` without a version suffix. Rejected: v1 and v2 would need a later rename anyway.
- Keep `embrace` as a symlink or alias to `refecs_v1`. Rejected: two live names for one model, and the old name is not the model's identity.

## Consequences
- Positive: v1 and v2 are separate registry models and separate tests, and the fixture name states which version it holds.
- Negative: the registry key and the test key change, so references pinned to the `embrace` key must move to `refecs_v1`; pre-rename run artifacts stay under `artifacts/{simulation,comparisons,plots}/embrace/` as historical evidence only.

## Verification
`tests/test_sysml_fixtures.py` carries the `refecs_v1` key in `EXPECTED`, and `artifacts/simulation_registry.json` lists `refecs_v1` as its own model entry. `python3 scripts/build_models.py run refecs_v1` and `python3 -m pytest tests/` exercise the renamed fixture, and the future `refecs_v2` adds a sibling entry beside it.

## Review Trigger
When `refecs_v2` is added, or when a fixture version scheme other than a version suffix is adopted.
