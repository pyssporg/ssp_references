---
id: DEC-002
title: Reference Aircraft Vehicle Systems (RAVS) — `refecs` Becomes `ravs`
summary: The fixture family `refecs_v1`/`refecs_v2` becomes `ravs_v1`/`ravs_v2`, "Reference Aircraft Vehicle Systems", because the modelled system is no longer ECS-specific.
date: 2026-11-19
status: accepted
layers: [architecture, verification]
state: 04-verification/co_simulation_fixture_mapping.md
artifacts:
  - models/ssp/ravs_v1
  - models/ssp/ravs_v1/architecture/01-interfaces.sysml
  - models/ssp/ravs_v1/architecture/02-parameters.sysml
  - models/ssp/ravs_v1/architecture/03-components.sysml
  - models/ssp/ravs_v1/architecture/04-structure.sysml
  - models/ssp/ravs_v1/architecture/05-analyses.sysml
  - models/ssp/ravs_v1/build.py
  - models/ssp/ravs_v1/FIXTURE.md
  - models/ssp/ravs_v2
  - models/ssp/ravs_v2/architecture/01-interfaces.sysml
  - models/ssp/ravs_v2/architecture/02-parameters.sysml
  - models/ssp/ravs_v2/architecture/03-components.sysml
  - models/ssp/ravs_v2/architecture/04-structure.sysml
  - models/ssp/ravs_v2/architecture/05-analyses.sysml
  - models/ssp/ravs_v2/build.py
  - models/ssp/ravs_v2/FIXTURE.md
  - models/README.md
  - tests/test_sysml_fixtures.py
  - artifacts/simulation_registry.json
  - docs/breakdown/04-verification/co_simulation_fixture_mapping.md
  - docs/breakdown/04-verification/co_simulation_test_strategy.md
  - docs/breakdown/04-verification/ecosystem_adoption_assessment.md
  - docs/breakdown/04-verification/simulation_registry_coverage_review.md
  - docs/breakdown/05-operation/results-interpretation.md
  - docs/breakdown/06-evolution/selected/scenario-ownership-strategy-for-ssp-fixtures.md
supersedes: []
superseded_by: []
related: [DEC-001, PD-004, DD-017]
---

# DEC-002: Reference Aircraft Vehicle Systems (RAVS) — `refecs` Becomes `ravs`

## Context
`refecs` expanded to "Reference Environmental Control System", a name that fit
`refecs_v1`, which models an ECS loop. `refecs_v2` is a full aircraft vehicle
system — air data, fuel, an ECS hardware and software pair, and a hydraulic
valve subsystem — so the ECS expansion no longer describes what the family
models. The family keeps the versioned sibling structure that DEC-001
established; only the family name changes.

## Decision
On 2026-11-19 the family is renamed "Reference Aircraft Vehicle Systems (RAVS)",
so `models/ssp/refecs_v1` becomes `models/ssp/ravs_v1` and
`models/ssp/refecs_v2` becomes `models/ssp/ravs_v2`. SysML packages become
`RavsV1` and `RavsV2`, registry and test keys become `ravs_v1` and `ravs_v2`,
generated `artifacts/*/refecs_*` trees move to `ravs_*`, and no alias or
symlink keeps a `refecs` name; the breakdown leaves that cite the fixtures follow.

## Rationale
A name is a claim about scope. "Reference Aircraft Vehicle Systems" states the
system boundary the fixtures now reproduce and stays accurate when a later
version widens it further. Renaming both versions in one change keeps the
family internally consistent: a `ravs_v1` beside a `refecs_v2` would suggest
two different families.

## Alternatives Considered
- Keep `refecs` and re-expand it to "Reference Aircraft Vehicle Systems". Rejected: the acronym survives only as a backronym that no longer reads from the words, and every reader would carry the old expansion.
- Rename v2 only and leave v1 as `refecs_v1`. Rejected: the versioned family of DEC-001 would split into two naming schemes.
- Add `ravs_v*` as new names and keep `refecs_v*` as aliases. Rejected: two live names per model, and the registry, tests, and archives would disagree about which name owns the fixture.

## Consequences
- Positive: fixture, package, registry, and test names all state the actual system scope, and the family keeps one naming scheme across versions.
- Negative: registry and test keys change, so anything pinned to `refecs_v1`/`refecs_v2` must move to the new keys; history records (DEC-001, AD-012, AD-013) keep the old name and are not rewritten, so the archive still reads `refecs`.

## Verification
`git ls-files | grep -i refecs` returns nothing, and `rg -n -i refecs` outside `docs/archive/` and generated caches returns nothing. `artifacts/simulation_registry.json` lists `ravs_v1` and `ravs_v2` as separate models, `tests/test_sysml_fixtures.py` carries both keys, `python3 scripts/build_models.py run ravs_v1` and `... run ravs_v2` rebuild the exported SSPs, and `python3 -m pytest tests/test_sysml_fixtures.py` passes.

## Review Trigger
When a third version is added, or when a name shorter than "Reference Aircraft Vehicle Systems" is adopted for the family.
