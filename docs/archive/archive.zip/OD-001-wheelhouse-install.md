---
id: OD-001
title: Default Install Uses the Pinned Wheelhouse
summary: The default install resolves the six pyssp distributions from wheelhouse/ pins; editable checkouts are a development opt-in.
date: 2026-11-04
status: superseded
layers: [operation]
state: docs/breakdown/05-operation/install-model.md
artifacts:
  - requirements.txt
  - requirements-dev.txt
  - requirements-wheelhouse.txt
  - scripts/install_wheelhouse.py
supersedes: []
superseded_by: [OD-002]
related: [INFO-003, INFO-008]
---

# OD-001: Default Install Uses the Pinned Wheelhouse

## Context
Editable checkout installs were the default for the six pyssp distributions. That hid what a built wheel actually contains: one tree shipped 2 of 30 packages (`EVAL-013`). The six distributions also declare an incomplete dependency graph, so a resolver cannot install them from an index.

## Decision
The default install resolves the six pyssp distributions from the pinned wheel set in `wheelhouse/`, built from the `3rd_party/` trees by `scripts/install_wheelhouse.py`. Editable checkouts become an explicit development opt-in in `requirements-dev.txt`.

## Rationale
- An editable install hid a wheel that shipped 2 of 30 packages (`EVAL-013`).
- The six distributions declare an incomplete dependency graph, so PyPI resolution fails.
- Testing the built artifact requires the wheel, not the checkout.

## Alternatives Considered
- PyPI-only: rejected; the distributions are unpublished or carry incomplete metadata.
- Git-ref-only: rejected; pip builds from source, so the installed artifact is never the verified wheel.

## Consequences
- Positive: default install is the tested artifact, and the development path is explicit.
- Negative: `wheelhouse/` is generated and git-ignored; each tree's CI must build its own wheel; upstream metadata edits live in the submodule repos and are lost unless pushed upstream.

## Verification
`python3 scripts/install_wheelhouse.py check` confirms one wheel per pin, and install smoke tests run against the installed wheels.

## Review Trigger
Revisit when a distribution publishes to a public index with a complete dependency graph.
