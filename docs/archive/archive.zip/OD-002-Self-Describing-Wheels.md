---
id: OD-002
title: Self-Describing Wheels Install From GitHub Release Assets
summary: Each pyssp wheel names sibling release assets as direct URL dependencies, and the default install fetches those URLs.
date: 2026-11-04
status: accepted
layers: [operation]
state: docs/breakdown/05-operation/install-model.md
artifacts:
  - requirements.txt
  - requirements-dev.txt
  - requirements-wheelhouse.txt
  - scripts/install_wheelhouse.py
supersedes: [OD-001]
superseded_by: []
related: [INFO-003, INFO-008, INFO-011, EVAL-013]
---

# OD-002: Self-Describing Wheels Install From GitHub Release Assets

## Context
`wheelhouse/` pinned the six distributions, but the mirror could not satisfy their dependency graph: each wheel named its siblings only by distribution name, so no offline or index resolver installed them. Editable installs were the working default, so installs took checkouts instead of the tested wheel and hid its defects (`EVAL-013`).

## Decision
Each vendored distribution became self-describing: its wheel metadata names sibling GitHub release assets as PEP 508 direct references. `requirements.txt` names the same release URLs, `wheelhouse/` became an offline mirror and completeness gate, and development kept the mirror pins plus editable checkouts. This superseded `OD-001`.

## Rationale
- A direct URL names the exact tested asset; a name-only dependency could not resolve from any index or mirror.
- Editable installs hid a wheel that shipped 2 of 30 packages (`EVAL-013`); only the wheel shows what users get.
- A mirror serves the six wheels but not the sibling URLs inside their metadata, so it serves offline use only.

## Alternatives Considered
- Name-only dependencies with a private index: rejected; the distributions are unpublished and their metadata was incomplete.
- Mirror-only default: rejected; offline resolution cannot follow the metadata URLs, and PyPI rejects direct-URL dependencies.
- Git-ref dependencies: rejected; pip builds from source, so the installed artifact is never the verified wheel.

## Consequences
- Positive: the default install fetches the wheels CI attached to the tag, and any gap between `requirements.txt` and wheel metadata surfaces as an install error.
- Negative: installs need network access to GitHub, an unreleased `v<version>` tag fails with a 404, and a renamed asset breaks every dependent until tag and filename move together.

## Verification
`python3 scripts/install_wheelhouse.py check` gates mirror completeness; a clean-venv `pip install -r requirements.txt` confirms the release URLs resolve; smoke tests run against the installed wheels.

## Review Trigger
Revisit when the distributions publish to a public index with a complete dependency graph, or when GitHub release hosting stops being acceptable for installs.
