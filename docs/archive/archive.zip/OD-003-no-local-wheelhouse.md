---
id: OD-003
title: No Local Wheelhouse
summary: Installs resolve the six distributions' GitHub release assets directly; the repository keeps no local wheelhouse.
date: 2026-11-04
status: accepted
layers: [operation]
state: docs/breakdown/05-operation/install-model.md
artifacts:
  - requirements.txt
  - requirements-dev.txt
supersedes: []
superseded_by: []
related: [OD-002, INFO-003, INFO-008, INFO-011, EVAL-013]
---

# OD-003: No Local Wheelhouse

## Context
`OD-002` kept `wheelhouse/` as an offline mirror and wheel-completeness gate beside the release-URL default. The mirror duplicated what the release assets already carry, and it could not serve the metadata URLs it was meant to stand in for.

## Decision
The local wheelhouse was removed: `requirements-wheelhouse.txt`, `scripts/install_wheelhouse.py`, `scripts/workflow/pins.py`, and `wheelhouse/` are gone. Default and development installs resolve the release URLs directly. `OD-002` stands, minus its mirror half.

## Rationale
- The six release assets returned 200, and a full `pip install --dry-run -r requirements.txt` resolved from `requirements.txt` alone; the mirror added no install path.
- A mirror cannot satisfy the direct URLs named inside wheel metadata; only the release assets can.
- Each package's own CI already gates wheel completeness.

## Alternatives Considered
- Keep the mirror as an offline-only cache: rejected; no offline workflow used it, and it cost a manifest, a script, and pins kept in lockstep.
- Keep `pins.py` as the completeness gate: rejected; that gate belongs to the producing package's CI, not this repository.

## Consequences
- Positive: one fewer script and manifest to maintain, and the default install is the only install path.
- Negative: no offline install path and no wheel-completeness gate in this repository; an unreleased tag or renamed asset fails the install with a 404.

## Verification
The six assets were verified with HTTP 200 responses, and a `--dry-run` install resolved from `requirements.txt` alone. `pb check --strict` and `pb node-size --strict` cover the state leaf (`INFO-011`).

## Review Trigger
Revisit when the distributions publish to a public index with a complete dependency graph, or when offline installs become a requirement.
