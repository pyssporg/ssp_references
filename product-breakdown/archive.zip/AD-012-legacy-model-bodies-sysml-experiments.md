---
id: AD-012
title: Legacy Model Bodies May Carry SysML-Authored Experiments
summary: A legacy SSD may stay the model body while its study and experiment are authored in SysML.
date: 2026-10-23
status: accepted
layers: [architecture, implementation]
state: 02-architecture/architecture.md
artifacts:
  - models/ssp/dcmotor/architecture/dcmotor.sysml
  - models/ssp/embrace/architecture/embrace.sysml
  - scripts/utils/authoring.py
  - artifacts/simulation_registry.json
supersedes: []
superseded_by: []
related: [PD-006, DD-011]
---

# AD-012: Legacy Model Bodies May Carry SysML-Authored Experiments

## Context

dcmotor and embrace carry large legacy SSD hierarchies: six FMUs, nested
systems, and a 165-parameter SSV. Re-authoring that in SysML moves the whole
structure for no gain. Experiments still need one authored home.

## Decision

A legacy SSD and its resources stay the model body.
A `part def <Model> :> SspModel` boundary marker declares the model in SysML,
with no parts or connectors.
Its `Study` applies no scenario and declares the experiment.
The build derives `study.json`, keeps the legacy SSD, and generates the LS-REF
experiment from the descriptor.

## Rationale

The hierarchy is already authored and reproducible. Moving it duplicates work
and risks drift. The experiment is small, independent of the hierarchy, and
benefits from the SysML study dialect.

## Alternatives Considered

- **Re-author the full hierarchy in SysML.** Rejected: duplicates 6 FMUs and 165 scenario parameters, and changes the artifact under test.
- **Keep `experiments.xml` authored.** Rejected: two authoring dialects for one concept.
- **Add a fake scenario set to satisfy the generator.** Rejected: fabricates a parameter and hides intent.

## Consequences

- Positive: experiments have one SysML source; the legacy body is untouched.
- Positive: the boundary stub can be replaced by a full composition later without changing the study.
- Negative: the stub is not exportable; `generate ssp` on it would yield an empty model.
- Negative: the generated LS-REF carries no tolerance; tolerance stays an FMU property.

## Verification

`tests/test_legacy_experiment_fixtures.py` checks the descriptor, the generated
experiment, and that the built SSD matches the legacy body. Simulation CSVs
match the pre-migration runs per backend.

## Review Trigger

Review if a fixture moves to a full SysML composition, or if tolerance must
become a study property.
