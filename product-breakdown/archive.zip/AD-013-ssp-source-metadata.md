---
id: AD-013
title: SspModel Declares Its Checked-In SSP Source
summary: An SspModel selects a checked-in SSP body with ssp_meta.source; the study records it as model_source.
date: 2026-10-23
status: accepted
layers: [architecture, implementation]
state: 02-architecture/architecture.md
artifacts:
  - models/ssp/dcmotor/architecture/dcmotor.sysml
  - models/ssp/embrace/architecture/embrace.sysml
  - scripts/utils/authoring.py
supersedes: []
superseded_by: []
related: [AD-012]
---

# AD-013: SspModel Declares Its Checked-In SSP Source

## Context

AD-012 let a legacy SSD stay the model body. The build still hardcoded
`<model>/ssp`. The authored source path had no home in SysML. `FmuMetadata`
already carries typed `source` on a part.

## Decision

Add an `SspMetadata` attribute-def hierarchy, mirroring `FmuMetadata`.
An `SspModel` carries `ssp_meta.source`, a repo-root-relative directory.
`study.json` records it as `model_source`.
The build copies that directory; `generate ssp` and `generate ssd` reject it.

## Rationale

The source is authoring data, not build logic. Typed metadata keeps one dialect
for FMU and SSP sources and keeps the path visible in the architecture file.

## Alternatives Considered

- **Hardcode `ssp/` in `build.py`.** Rejected: authoring data in executable code.
- **`pyssp_ssp_source` control attribute.** Rejected: typed metadata is the current dialect; FMU retired the control attribute.
- **Put the source on the Study.** Rejected: the body belongs to the model, not the study.

## Consequences

- Positive: the fixture selects its own body; no model-name convention.
- Positive: `model_source` reaches the build through the standard descriptor.
- Negative: a composition with `ssp_meta` is study-only and not exportable.
- Negative: the source must be a directory, not an `.ssp` archive.

## Verification

`tests/test_ssp_metadata.py` covers descriptor output, unset source, and export
rejection. `tests/test_legacy_experiment_fixtures.py` asserts both fixtures
record their source and build from the legacy body.

## Review Trigger

Review when an SSP archive can be selected, or when the body moves into SysML.
