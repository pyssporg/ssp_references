---
id: AD-014
title: No LS-REF Artifacts or Parsing
summary: The study descriptor is the experiment contract; the build writes no experiments.xml and no stage parses LS-REF.
date: 2026-10-23
status: accepted
layers: [architecture, implementation]
state: 02-architecture/architecture.md
artifacts:
  - scripts/utils/authoring.py
  - scripts/workflow/setup.py
  - scripts/workflow/layout.py
  - tests/test_legacy_experiment_fixtures.py
supersedes: []
superseded_by: []
related: [AD-012, AD-013]
---

# AD-014: No LS-REF Artifacts or Parsing

## Context

Only dcmotor and embrace wrote a generated LS-REF experiment. Every registry
case already carried a study descriptor. The LS-REF parser in `setup.py` was a
fallback that no registered case used. Two experiment sources invited drift.

## Decision

Retire all repo-owned LS-REF use.

- `build_legacy_fixture` copies the checked-in body without writing LS-REF.
- `SimulationSetup.from_spec` requires a study descriptor and raises otherwise.
- `setup.json` no longer records an `ls_ref_experiments` path.
- `pyssp_standard` keeps its LS-REF implementation as public API.

This partially supersedes `AD-012`.

## Rationale

One experiment contract beats a packaging copy. The study descriptor already
carries the window, step, and description. Removing the fallback deletes a
second parser and one manifest field.

## Alternatives Considered

- **Keep generated LS-REF as standalone metadata.** Rejected: duplicates the descriptor and needs a test to keep both in sync.
- **Keep the runtime parser as a fallback.** Rejected: dead for every registered case and hides a missing descriptor.

## Consequences

- Positive: one experiment source; no LS-REF sync test.
- Positive: a case without a study descriptor fails loudly.
- Negative: no fixture exercises LS-REF packaging; standard-artifact coverage narrows.
- Neutral: `pyssp_standard` LS-REF types stay available to other consumers.

## Verification

`tests/test_legacy_experiment_fixtures.py` asserts no built `experiments.xml`.
`tests/test_workflow.py` asserts a spec without a study descriptor is rejected.

## Review Trigger

Review when a fixture must ship a standalone LS-REF experiment for an external
consumer.
