---
id: AD-015
title: Per-Fixture Build Scripts Are Thin Runners
summary: build.py declares one fixture's inputs; shared authoring helpers own the build steps.
date: 2026-10-23
status: accepted
layers: [implementation]
state: 03-implementation/workflow.md
artifacts:
  - scripts/utils/authoring.py
  - models/ssp/signal_step_add/build.py
  - models/ssp/VanDerPol/build.py
  - models/ssp/dcmotor/build.py
supersedes: []
superseded_by: []
related: [AD-012, AD-014]
---

# AD-015: Per-Fixture Build Scripts Are Thin Runners

## Context

Twenty-one build scripts repeated path bootstrap, constants, and a main call.
Six defined the same no-op package step. The shared steps already lived in
`scripts/utils/authoring.py`. The build entry still needed one file per fixture
for discovery and direct invocation.

## Decision

Keep one `build.py` per fixture and reduce it to a thin runner.

- `run_fixture` derives the repo root and model name, defaults composition and
  study, and accepts named package steps.
- `run_legacy_fixture` does the same for checked-in SSP bodies.
- `package_nothing` has one definition.
- `utils/model.py` and the campaign's unused build-only nodes are deleted.

## Rationale

Discovery and direct invocation stay unchanged. Fixture-specific packaging
remains visible in the fixture directory. The duplicated orchestration leaves
the script.

## Alternatives Considered

- **One declarative build table, delete trivial build.py files.** Rejected: removes the documented per-fixture entry point for a small extra gain.
- **Keep duplicated boilerplate.** Rejected: about 600 lines with no fixture meaning.

## Consequences

- Positive: fixture scripts show only what differs.
- Positive: one place owns build orchestration and printing.
- Negative: the shared runner is a new indirection every fixture depends on.

## Verification

`python3 scripts/build_models.py run-all` rebuilds all fixtures.
`python3 -m pytest tests/` passes.

## Review Trigger

Review when a fixture needs a build step that `run_fixture` cannot express.
