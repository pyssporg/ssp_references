---
id: ADR-001
title: Three-Stage Pipeline Architecture
summary: The pipeline has three file-based stages: Build, Simulate, Compare.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - scripts/build_models.py
  - scripts/run_simulations.py
  - scripts/run_comparisons.py
supersedes: []
superseded_by: []
related: []
---

# ADR-001: Three-Stage Pipeline Architecture

## Context

The repository needed a clear separation of concerns between building SSPs,
running simulations, and comparing results. Without explicit stage boundaries,
build scripts could leak into simulation logic, comparison scripts could
re-execute simulations, and the pipeline would lose independent invocability.

## Decision

Adopt the three-stage pipeline:

- **Build** (`scripts/build_models.py` + per-model `build.py`): transforms
  authored model definitions into built SSP roots under `artifacts/models/`.
- **Simulate** (`scripts/run_simulations.py`): reads the simulation registry,
  prepares setup manifests, dispatches to backend adapters, and records results
  under `artifacts/simulation/`.
- **Compare** (`scripts/run_comparisons.py`): loads existing simulation results
  and produces pairwise engine-to-engine metrics under
  `artifacts/comparisons/`.

## Rationale

See Decision.

## Alternatives Considered

1. **Monolithic pipeline** — A single script that builds, simulates, and
   compares each model in one pass.
2. **Two-stage pipeline** — Build combined with setup, simulate and compare
   combined.
3. **Three-stage pipeline** — Build, Simulate, and Compare as independent
   stages with file-based interface contracts.

## Consequences

- Each stage can be invoked, debugged, and tested independently.
- The build stage does not need backend libraries installed; the simulation
  stage does not need build tooling installed.
- Adding a new backend adapter does not require changes to build scripts or
  the comparison entry point.
- Cross-stage coordination requires explicit manifest files (`setup.json`,
  `simulation.json`, `comparison.json`), adding some overhead for the
  decoupling benefit.

---

*Trace: Satisfies the Build → Simulate → Compare commitment in
[00-intent/intent.md](../../00-intent/intent.md) and Section 1 of
[02-architecture/architecture.md](../architecture.md).*

## Verification

None.

## Review Trigger

None.
