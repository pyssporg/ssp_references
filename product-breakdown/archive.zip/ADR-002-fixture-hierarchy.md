---
id: ADR-002
title: Fixture Hierarchy
summary: Fixtures are organized in four classes: FMU blocks, simple SSPs, deterministic signal fixtures, and composite SSPs.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - models/ssp
  - models/fmu
supersedes: []
superseded_by: []
related: []
---

# ADR-002: Fixture Hierarchy

## Context

The repository needed a consistent way to organize its growing collection of
SSP fixtures. Without an explicit hierarchy, new fixtures could be added
ad-hoc with inconsistent structure, and it would be unclear which class of
fixture serves which testing purpose.

## Decision

Adopt a four-class fixture hierarchy:

1. **FMU building blocks** (`models/fmu/`) — Reusable signal-processing FMUs
   (sources, gains, combiners) that are the leaf dependencies.
2. **Simple reference SSPs** (`models/ssp/`) — Single-FMU SSPs serving as basic
   behavioral checks.
3. **Deterministic signal-propagation fixtures** (`models/ssp/`) — SSPs
   composed from two or more FMU building blocks to exercise specific
   propagation scenarios.
4. **Composite SSPs** (`models/ssp/`) — Multi-component SSPs exercising
   realistic coupling behavior.

## Rationale

See Decision.

## Alternatives Considered

1. **Flat fixture collection** — All SSPs treated as equal, distinguished only
   by metadata tags.
2. **Two-level hierarchy** — Simple reference models at one level, everything
   else at another.
3. **Four-class hierarchy** — FMU building blocks, simple reference SSPs,
   deterministic signal-propagation fixtures, and composite SSPs.

## Consequences

- New fixtures have a clear architectural home and purpose class.
- The hierarchy maps directly to comparison tolerance expectations (tightest
  for propagation fixtures, moderate for simple references, broadest for
  composites).
- Adding a new fixture class would require an explicit decision and an ADR
  update.
- The four classes are not always mutually exclusive (a composite could contain
  propagation fixtures), but the hierarchy captures the primary intent.

---

*Trace: Satisfies the fixture organization described in Section 2 of
[02-architecture/architecture.md](../architecture.md).*

## Verification

None.

## Review Trigger

None.
