---
id: ADR-003
title: Runtime Configuration Belongs to the Simulation Registry
summary: The registry is the runtime configuration source; `setup.json` freezes the selected window, tolerance, and policy.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - artifacts/simulation_registry.json
  - scripts/run_simulations.py
supersedes: []
superseded_by: []
related: [DD-001, DD-009]
---

# ADR-003: Runtime Configuration Belongs to the Simulation Registry

## Context

The build stage produces SSPs that carry `experiments.xml` (from the LS-REF
convention) containing simulation window, tolerance, and other metadata. Early
designs considered using this file directly as the runtime configuration source
for simulation dispatch.

## Decision

Use approach 2: The simulation window, tolerance, backend list, and compare
signals are read from `experiments.xml` and the registry at setup time, then
frozen into `artifacts/simulation/<model>/<study>/setup.json`. All subsequent
stages read `setup.json`, not `experiments.xml`.

## Rationale

See Decision.

## Alternatives Considered

1. **Parse `experiments.xml` at runtime** — Each backend adapter reads
   `experiments.xml` directly to configure the simulation window and tolerance.
2. **Freeze into `setup.json`** — A setup stage reads `experiments.xml` once
   and writes a flat `setup.json` that the runtime layer consumes.
3. **Dual source** — Some settings from `experiments.xml`, others from a
   separate registry file.

## Consequences

- Backend adapters do not need to parse XML or understand LS-REF conventions.
- `setup.json` is the single flat manifest consumed by both simulation and
  comparison stages.
- If `experiments.xml` changes, `setup.json` must be regenerated (re-run setup).
- The registry (`simulation_registry.json`) is the exclusive source of truth
  for which model/study/backend combinations are active.

---

*Trace: Satisfies the runtime contract described in Section 5 of
[02-architecture/architecture.md](../architecture.md) and decision
[DD-001: Simulation Settings Belong to the Runtime Layer](../../03-implementation/decisions/DD-001-simulation-settings-runtime-layer.md).*

---

**Amendment (2026-10-22): Study Descriptor Feeds `setup.json`**

The freeze-into-`setup.json` decision stands. The *source* of the window and
tolerance changes for migrated fixtures:

- the study descriptor supplies window, step size, and tolerance;
- the registry supplies backends, compare signals, references, and gate policy;
- `setup.json` is written under
  `artifacts/simulation/<model>/<study>/setup.json`;
- the exported SSP's `experiments.xml` is a standalone default, not the runtime
  source.

The registry remains the exclusive source of truth for the active study/backend
matrix. See [DD-009](../../03-implementation/decisions/DD-009-runtime-scenario-injection.md).

## Verification

None.

## Review Trigger

None.
