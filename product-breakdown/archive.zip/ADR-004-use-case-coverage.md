---
id: ADR-004
title: Use-Case Coverage Taxonomy as the Primary Coverage Lens
summary: The use-case taxonomy is the primary coverage lens for the fixture suite.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - product-breakdown/04-verification/co_simulation_fixture_mapping.md
supersedes: []
superseded_by: []
related: [ADR-001, ADR-002, ADR-003]
---

# ADR-004: Use-Case Coverage Taxonomy as the Primary Coverage Lens

## Context

The fixture suite had no systematic framework for evaluating what system
simulation behavior was actually covered by the test suite. Test functions
extensively covered pipeline mechanics (registry management, manifest
round-trip, signal name normalization, MAT-to-CSV extraction) but never
validated that the pipeline actually simulates intended system behavior.
Without a shared coverage taxonomy, new fixture and test work was prioritized
ad-hoc rather than against a gap map.

Meanwhile, two low-level function verification tests checked implementation
details (reference CSV cell values, FMU metadata attributes) that belong in
simulation engine repositories rather than this fixture suite.

## Decision

Adopt option 3: Publish the use-case taxonomy (UC-1 through UC-16) and
per-use-case gap assessments as the canonical coverage framework for the
fixture suite. The taxonomy is documented in
`product-breakdown/06-evolution/use_case_coverage_analysis.md`.

All new fixture and test work is prioritized against the gap map. Coverage
gaps directly inform the priority of fixture-add candidates (IMP-009,
IMP-010), pipeline integration tests (IMP-013), and signal propagation
coverage tests (IMP-017).

The two identified engine-level verification tests
(`test_reference_csvs_are_not_inverted`,
`test_modelica_block_fmus_expose_dependency_metadata`) are flagged for
transfer to engine repositories.

## Rationale

See Decision.

## Alternatives Considered

1. **No taxonomy** — Continue ad-hoc prioritization of new fixtures and tests.
2. **Informal checklist** — A non-versioned list of use-cases maintained
   outside the documentation structure.
3. **Published taxonomy with gap analysis** — A versioned, documented use-case
   taxonomy (UC-1 through UC-16) with per-use-case gap assessments, published
   as a stable reference artifact.

## Consequences

### Positive

- Clear shared understanding of what the test suite actually covers vs. what
  it should cover.
- Data-driven prioritization of new fixture and test work.
- Removal of engine-level verification burden from this repo (after transfer).
- Measurable progress: coverage gaps are tracked and closed over time.

### Negative

- Taxonomy may need refinement as new fixture types are added.
- Matrix must be kept in sync with the actual test suite (requires periodic
  review per improvement cycle).

**Affected Artifacts**

- `product-breakdown/06-evolution/use_case_coverage_analysis.md` — the taxonomy
  and gap analysis (new)
- `product-breakdown/04-verification/co_simulation_test_strategy.md` — updated
  to reference taxonomy
- `product-breakdown/06-evolution/backlog/improvement-backlog.md` — matrix
  replaced with cross-reference
- `product-breakdown/06-evolution/backlog/complete/IMP-011.md` — moved and
  marked completed

## Verification

- The taxonomy document exists at the expected path and contains all 16 use-cases
  with coverage status and gap assessments.
- `co_simulation_test_strategy.md` contains a reference to the taxonomy.
- `improvement-backlog.md` contains a cross-reference, not an embedded matrix.
- IMP-011 is moved to `complete/` with updated status.

## Review Trigger

- When a new fixture type is added that does not map to an existing use-case.
- When a coverage gap is closed; update the gap assessment and coverage status.
- If the taxonomy becomes stale relative to the test suite (checked each
  improvement cycle).

---

*Trace: Extends ADR-001 (pipeline) by defining what the pipeline should
validate. Extends ADR-002 (fixture hierarchy) by mapping fixture classes to
use-cases. Extends ADR-003 (registry) by defining which registered cases
exercise which use-cases. Satisfies the coverage-analysis commitment stated
in IMP-011 (`product-breakdown/06-evolution/backlog/complete/IMP-011.md`).*
