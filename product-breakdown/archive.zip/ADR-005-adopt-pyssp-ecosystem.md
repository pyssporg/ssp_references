---
id: ADR-005
title: Adopt the pyssp Ecosystem Behind Existing Stage Boundaries
summary: The repository adopts the pyssp ecosystem behind existing stage boundaries.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - 3rd_party/pyssp_workflow
  - scripts/run_campaign.py
supersedes: []
superseded_by: []
related: [ADR-001, ADR-003, ADR-007, ADR-008, ADR-009, ADR-010]
---

# ADR-005: Adopt the pyssp Ecosystem Behind Existing Stage Boundaries

## Context

The repository's simulation, comparison, and fixture-authoring code grew before
the current pyssp ecosystem existed. Three sibling projects now overlap with
that custom code:

- `pyssp_simulate` provides one SSP simulation interface for FMPy,
  OMSimulator, ssp4sim, and cosim, plus runtime SSP preparation, result
  normalization, permutation runs, and cross-engine comparison.
- `pyssp_sysml2` generates SSD, SSV, FMI model descriptions, and SysML v2
  architectures, and syncs SSD wiring back into SysML.
- `sequence_extensions` provides a task/flow engine with retries, timeouts,
  bounded parallelism, and a JSON-lines audit log.

Continuing to maintain equivalent code in this repository duplicates upstream
effort and hides ecosystem gaps behind local patches. The repository's value is
the fixture suite and the VV evidence it produces, not a private simulation
framework.

## Decision

Adopt option 3.

- `scripts/workflow/simulate.py` is a thin adapter over `pyssp_simulate`.
  Local shims in `scripts/workflow/engine_compat.py` cover two current upstream
  gaps: FMPy's SSP 2.0 validation/boundary-connection handling and
  OMSimulator's fixed-step event suppression. FMPy parameter bindings are
  passed explicitly because the upstream FMPy backend ignores them.
- `scripts/workflow/gate.py` turns comparison metrics into a pass/fail verdict.
  Engine-to-engine and reference-CSV comparisons share one gate policy.
- `scripts/workflow/reference.py` compares runs against trusted CSV baselines;
  reference baselines are not a substitute for engine-to-engine comparison.
- `scripts/run_campaign.py` orchestrates the existing entry points with
  `sequence_extensions`. It requires Python 3.11+ and is optional.
- `scripts/check_sysml_roundtrip.py` measures SSD → SysML → SSD structural
  loss through the external `pyssp` CLI. It reads and writes only SSD files,
  so the SysML tool can live in its own environment and track its own
  `pyssp_sysml2` / `pyssp_standard` versions.

The Build → Simulate → Compare stage contracts, registry authority, and
artifact locations remain unchanged.

## Rationale

See Decision.

## Alternatives Considered

1. **Keep the custom pipeline and vendor the libraries as references only.**
   Preserves the status quo but keeps duplication and makes gap discovery
   incidental.
2. **Replace the whole pipeline with upstream libraries.**
   Removes the stage contracts, manifests, and VV policy that the repository
   exists to provide; also fails on fixtures with known engine gaps.
3. **Adopt the libraries behind the existing stage boundaries.**
   Use `pyssp_simulate` as the simulation substrate, `sequence_extensions` as
   an optional campaign orchestrator, and `pyssp_sysml2` as an authoring and
   round-trip evaluation tool, while retaining the registry, setup manifests,
   comparison artifacts, reference baselines, and explicit compatibility shims.

## Consequences

- Duplicated ssp4sim configuration, runtime SSP preparation, and result CSV
  handling are removed from the repository.
- Upstream gaps are now explicit and testable instead of implicit in private
  code. The current gaps are recorded in
  `product-breakdown/04-verification/ecosystem_adoption_assessment.md`.
- The gate uses a time-shift-tolerant error so ordinary co-simulation scheduling
  skew does not masquerade as a modeling failure. Raw pointwise error remains
  in the metrics for diagnostics.
- The campaign layer now runs in the same Python 3.11 runtime as the core
  pipeline.
- SysML authoring is not yet a build input. The SSD → SysML → SSD round-trip
  now preserves connector kinds, parameter values/source, implementation, and
  the default experiment. `pyssp_sysml2` targets the refactored
  `pyssp_standard` model API and is invoked through its CLI; nested SSD
  systems remain unsupported by the sync path.

---

**Amendment (2026-10-22): Comparison Leaves the Substrate**

The Context above lists cross-engine comparison as part of `pyssp_simulate`.
That is no longer true.

`pyssp_simulate` 0.2.0 removes `compare.py`, the `compare` CLI subcommand, and
the comparison exports. Measurement and judgment now live in `pyssp_vv`, which
also owns the evidence bundle; `pyssp_workflow` composes build, run, compare,
and verify steps as nodes. Both are submodules of this repository.

What changes for this repository:

- The comparison rationale for adopting `pyssp_simulate` no longer applies. The
  substrate is adopted for execution, runtime SSP preparation, and result
  normalisation only.
- This repository's comparison layer under `scripts/workflow/` is unchanged and
  still supplies the gate, reference baselines, and time-shift metrics. It is
  the intended consumer of `pyssp_vv.measure` when that migration is scheduled;
  until then the stage boundary and artifact contracts stand.
- `pyssp_simulate` may import `pyssp_vv.measure` internally for permutation
  runs. That surface is not re-exported, and `pyssp_vv.judge` is never imported
  by the substrate.

Why an amendment rather than a new ADR: the decision to adopt the pyssp
ecosystem still stands. One entry in its rationale moved, and the reasoning is
recorded where the change happened.

Traceability:

- `pyssp_simulate` ADR-001 — comparison moves to `pyssp_vv`
- `pyssp_vv` ED-001 — measurement and judgment in one package

---

**Amendment 2 (2026-10-22): The Development Tree Moves to `pyssp_workflow`**

The decision above adopts the ecosystem; it did not say where the checkouts
live. They were linked individually here, which made this repository the place
where capability development was pinned.

That moved. `pyssp_workflow` now links `pyssp_standard`, `pyssp_simulate`,
`pyssp_sysml2`, `pyssp_vv`, and `sequence_extensions` under its own
`3rd_party/`, and this repository links `pyssp_workflow` only. See
`pyssp_workflow` ADR-003.

What changes here:

- `requirements.txt`, `requirements-sysml.txt`, and `requirements-campaign.txt`
  install editable checkouts from
  `3rd_party/pyssp_workflow/3rd_party/...`.
- `git submodule update --init --recursive` is required; a non-recursive update
  leaves `pyssp_workflow` without its capabilities.
- No stage boundary, entry point, or artifact contract changes. The pipeline
  boundary table and this ADR's adoption decision stand.

What does not change: the repositories, their public APIs, and the dependency
direction. `pyssp_vv` still imports nothing from the ecosystem; `pyssp_workflow`
still composes it.

Cost accepted: a capability bump now needs a `pyssp_workflow` gitlink commit
before this repository records it, so one capability change is three commits
instead of two.

---

**Amendment 3 (2026-10-22): Authoring and Verification Ownership Move**

The adoption decision stands. Three statements in the original decision are
now superseded by later ADRs:

- **SysML authoring is now a build input.** ADR-007 moves SysML → SSP
  derivation into `pyssp_workflow.authoring`, invoked through the `pyssp` CLI.
  The round-trip checker remains artifact-only, but it is no longer the only
  SysML tool path.
- **Comparison and verification are migrating to `pyssp_vv`.** ADR-008 records
  the capability ownership: measurement in `pyssp_vv.measure`, judgment in
  `pyssp_vv.judge`, and composition in `pyssp_workflow` nodes. The local
  comparison layer is transitional, not the target.
- **Models and studies are separated.** ADR-009 and ADR-010 make `SspModel`
  definitions exportable, make `Study` definitions consumers of exported SSPs,
  and move scenario/experiment application to runtime.

What does not change: the stage contract, the registry as runtime source of
truth, and the artifact-boundary rule. The local engine shims remain until the
corresponding upstream gaps close.

## Verification

None.

## Review Trigger

None.
