---
id: ADR-006
title: Exchange Standardized Artifacts at Tool Boundaries
summary: Tool boundaries exchange standardized artifacts, never Python model objects.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - scripts/check_sysml_roundtrip.py
  - product-breakdown/02-architecture/pipeline-boundaries.md
supersedes: []
superseded_by: []
related: []
---

# ADR-006: Exchange Standardized Artifacts at Tool Boundaries

## Context

The pyssp libraries evolve independently: `pyssp_standard` changes its model
API, `pyssp_sysml2` tracks that API, and the simulation engine adapters track
their own upstream packages. Making one library understand another library's
object model creates a compatibility layer that must change whenever either
side changes.

The repository already defines Build → Simulate → Compare as file-based
stages. The same principle needs to apply to evaluation tools such as the SSD
→ SysML → SSD round-trip checker.

## Decision

All tool boundaries in this repository exchange standardized artifacts, not
Python objects. The canonical boundary contract is maintained in
[Pipeline and Tool Boundaries](../pipeline-boundaries.md):

- Build writes an unpacked SSP root (`SystemStructure.ssd`, `resources/`,
  `experiments.xml`).
- Simulate reads the SSP root and the simulation registry, and writes result
  CSV plus run manifests.
- Compare reads result manifests and result CSV files.
- The SysML round-trip checker reads an SSD, invokes an external `pyssp`
  executable, and compares the regenerated SSD.

Consequences for library coupling:

- The round-trip checker does not import `pyssp_sysml2` or `pyssp_standard`.
  It invokes the CLI and can point at a different environment with
  `--pyssp` or `PYSSP`.
- `pyssp_sysml2` targets the refactored `pyssp_standard` API directly
  (`ssd.xml`, `ssv.xml`, `Connector.type_name`). No compatibility shim is
  added to `pyssp_standard` for downstream callers.
- Each stage may run in its own virtual environment. Version alignment is
  required only where an artifact format changes, not where a Python model
  API changes.

## Rationale

See Decision.

## Alternatives Considered

1. **Keep one shared environment and add compatibility properties to
   `pyssp_standard`.** Rejected: it couples the standard library to one
   consumer's historical interface and hides version skew instead of
   isolating it.
2. **Rewrite every tool to a single internal model.** Rejected: it recreates
   the coupling and makes independent tool upgrades harder.
3. **Invoke external tools through subprocesses at artifact boundaries.**
   Accepted: it preserves independent versioning and makes the actual contract
   (SSP XML) testable.

## Consequences

- The SysML checker needs a `pyssp` executable. Without one it fails with an
  explicit message; it no longer silently imports a library from the runtime
  venv.
- Cross-tool behavior changes must be expressed as artifact changes or as an
  adapter inside the consuming tool, never by modifying the producer's model
  to match a consumer.
- Nested SSD systems remain a limitation of `pyssp_sysml2`; that limitation
  is now visible at the artifact boundary rather than hidden in shared
  in-memory objects.

---

*Trace: Satisfies the artifact-boundary rule in
[02-architecture/architecture.md](../architecture.md) and the canonical
contract in [Pipeline and Tool Boundaries](../pipeline-boundaries.md).*

## Verification

None.

## Review Trigger

None.
