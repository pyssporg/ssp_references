---
id: ADR-007
title: Authoring SysML at the Build Boundary
summary: `pyssp_workflow.authoring` derives SSP artifacts through the `pyssp` CLI at the build boundary.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - models/ssp/signal_step_gain/build.py
  - 3rd_party/pyssp_workflow
supersedes: []
superseded_by: []
related: [ADR-006, ADR-009, PD-004]
---

# ADR-007: Authoring SysML at the Build Boundary

## Context

ADR-006 keeps tool boundaries artifact-based and treats SysML as a round-trip
checker. The repository is now moving model authoring to SysML: `SspModel`
definitions, ports, FMU metadata, parameter interfaces, and study parameter
sets are authored in `*.sysml` and must become build inputs.

If each model build script invokes `pyssp_sysml2` directly, the repository
reintroduces the cross-library coupling ADR-006 removed, and every fixture
reimplements argument handling, validation, and error reporting.

## Decision

`pyssp_workflow.authoring` owns SysML → SSP derivation.

- It invokes the external `pyssp` CLI as a subprocess with explicit paths.
- It never imports `pyssp_sysml2` or `pyssp_vv`.
- Model `build.py` scripts call the generic authoring function and then perform
  only fixture-specific post-processing.
- The derived `.ssp` archive, SSD, and SSV files cross the boundary as
  standardized artifacts.
- `pyssp_standard` remains the build-stage API for inspecting and packaging the
  derived SSP. "Do not import `pyssp_sysml2`" does not mean "do not import
  `pyssp_standard`".

## Rationale

See Decision.

## Alternatives Considered

1. **Import `pyssp_sysml2` in every `build.py`** — Shortest call path, but
   couples every fixture to a Python model API and breaks ADR-006's boundary.
2. **Pre-generate SSD/SSV and check them in** — No build-time SysML dependency,
   but the generated artifacts become a second source of truth and drift.
3. **Implement the CLI invocation separately in each build script** — Keeps the
   boundary but duplicates error handling and path conventions.
4. **Implement one generic authoring function and node in `pyssp_workflow`** —
   Accepted. Keeps the boundary, centralizes the contract, and makes the
   authoring step schedulable.

## Consequences

- Migrated builds require a `pyssp` executable, either in the runtime
  environment or supplied through `PYSSP` / an explicit path.
- `pyssp_workflow` becomes part of the build environment; `pyssp_sysml2` may
  still run in its own environment.
- Build inputs now include `architecture/*.sysml` in the model directory.
- A failed SysML derivation is a build failure with captured CLI diagnostics,
  not a silent fallback to a checked-in SSD.
- The SysML round-trip checker remains an independent artifact-only tool.

**Trace**

Satisfies [ADR-006](ADR-006.md)'s artifact-boundary rule and
[PD-004](../../01-product/decisions/PD-004-sysml-sspmodel-authoring.md).
Model/study export rules are in [ADR-009](ADR-009.md).

## Verification

None.

## Review Trigger

None.
