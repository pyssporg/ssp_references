---
id: ADR-008
title: Workflow Capability Ownership and Node Boundaries
summary: `pyssp_workflow` owns generic pipeline behavior; `ssp_references` owns fixtures and policy data.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - 3rd_party/pyssp_workflow
  - scripts
supersedes: []
superseded_by: []
related: [ADR-005, ADR-006, ADR-007, ADR-009, ADR-010, PD-005]
---

# ADR-008: Workflow Capability Ownership and Node Boundaries

## Context

`ssp_references` still implements a large part of the pipeline locally:
simulation dispatch, runtime SSP handling, result normalization, comparison
metrics, gating, reference comparison, plotting, layout, manifests, and campaign
orchestration. The sibling repositories now own those capabilities:

- `pyssp_standard` — SSP assembly and XML model APIs.
- `pyssp_simulate` — simulation execution and runtime SSP preparation.
- `pyssp_vv` — measurement, judgment, policy, and evidence.
- `pyssp_sysml2` — SysML/SSD/SSV/SSM/SSP derivation.
- `sequence_extensions` — flow nodes, retries, timeouts, and parallelism.
- `pyssp_workflow` — composition of the above.

Keeping local equivalents hides upstream gaps and makes the fixture repository
carry maintenance that belongs to the capability repositories.

## Decision

`pyssp_workflow` owns generic pipeline behavior; `ssp_references` owns fixtures
and policy data.

| Concern | Owner | Local residue |
| --- | --- | --- |
| SysML → SSP | `pyssp_workflow.authoring` + `pyssp_sysml2` CLI | `architecture/*.sysml`, fixture-specific packaging |
| SSP assembly | `pyssp_workflow.build` + `pyssp_standard` | model `build.py` descriptor |
| Runtime SSP preparation | `pyssp_simulate.runtime` | documented engine shims only |
| Simulation dispatch | `pyssp_simulate` + `pyssp_workflow.execute` | documented engine shims only |
| Artifact layout and manifests | `pyssp_workflow` | root paths and registry data |
| Registry schema and expansion | `pyssp_workflow.plan`/registry | `simulation_registry.json` content |
| Measurement | `pyssp_vv.measure` | model-specific invariants as data |
| Judgment and verdicts | `pyssp_vv.judge` + `pyssp_vv.policy` | tolerance policy values |
| Reference comparison | `pyssp_vv.measure` + workflow node | reference CSV locations |
| Plots | `pyssp_vv.measure.figures` + `pyssp_workflow.report` | selected signals |
| Campaign orchestration | `pyssp_workflow.nodes` + `sequence_extensions` | model/study selection |

Additional rules:

- Build and simulation work is submitted through `sequence_extensions` nodes so
  models, studies, and backends can run in parallel.
- `ssp_references` does not implement measurement or judgment logic.
- Model-specific signal invariants move to registry data or SysML constraints.
- Local engine shims are permitted only while a documented upstream gap is open.

## Rationale

See Decision.

## Alternatives Considered

1. **Keep local implementations** — Rejected: duplicates capabilities and hides
   gaps.
2. **Replace everything at once** — Rejected: would remove stage contracts and
   break fixtures with known engine gaps.
3. **Staged migration behind existing stage boundaries** — Accepted.

## Consequences

- The custom comparison, gate, reference, and simulation layers shrink to thin
  registry adapters and nodes.
- `pyssp_vv` introduces an `invalid` verdict. The campaign must distinguish
  `invalid` (not fit to judge) from `fail` (criterion exceeded).
- Migration is ordered: authoring/build, simulation, measure/judge, experiments,
  reporting.
- The Build → Simulate → Compare stage contract remains stable. Migrated
  fixtures add the exported-model and study artifact locations described in
  [ADR-010](ADR-010.md); legacy locations remain until each fixture is ported.

**Trace**

Refines [ADR-005](ADR-005.md), [ADR-006](ADR-006.md), and
[PD-005](../../01-product/decisions/PD-005-fixtures-and-policy-not-pipeline.md).
SysML authoring is in [ADR-007](ADR-007.md); model/study rules are in
[ADR-009](ADR-009.md) and [ADR-010](ADR-010.md).

## Verification

None.

## Review Trigger

None.
