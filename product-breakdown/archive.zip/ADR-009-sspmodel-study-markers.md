---
id: ADR-009
title: `SspModel` and `Study` Marker Specialization
summary: `SspModel` definitions are exportable; `Study` definitions supply scenario data and are never exported.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - models/ssp/signal_step_gain/build.py
  - product-breakdown/02-architecture/architecture.md
supersedes: []
superseded_by: []
related: [ADR-007, ADR-010, PD-004, PD-006]
---

# ADR-009: `SspModel` and `Study` Marker Specialization

## Context

SysML architectures contain both exportable models and study definitions.
Without an explicit role marker, a build can accidentally export a study
composition as an SSP. Structural inheritance (`part def study :> Model`) is not
a viable marker: the current parser does not record part-def specialization and
does not inherit parts or connections, so a subtype composition is empty.

## Decision

Use explicit marker definitions in the same package:

```sysml
part def SspModel;
part def Study;

part def System :> SspModel {
  part step : Step;
  part gain : Gain;
  connect step.y to gain.u;
}

part def test_baseline :> Study {
  attribute experiment_baseline : Baseline;
  part sut : System;
  attribute nominal : NominalSet;
  bind sut.step.parameters.height = nominal.height;
}
```

Rules:

- `part def <Model> :> SspModel` is exportable as an SSP.
- `part def <Study> :> Study` is never exportable as an SSP.
- A study references its model through `part sut : <Model>`, not through
  structural inheritance.
- A study declares one experiment attribute initially.
- Parameter binds live in the study and target `sut.*`.
- `pyssp_sysml2` records `PartDefinition.specializes` and exposes
  `is_ssp_model()` / `is_study()` role helpers.
- `generate ssp` rejects a `:> Study` composition with a clear message.
- `generate study` (or an equivalent scenario command) emits study artifacts:
  SSV, SSM, and an experiment descriptor.

## Rationale

See Decision.

## Alternatives Considered

1. **Structural inheritance** — `part def test :> System`. Rejected: the parser
  and generator do not inherit parts/connections; the composition is empty.
2. **Naming convention only** — `test_*` prefixes. Rejected: fragile and
  invisible to the generator.
3. **Marker specialization** — Accepted. Explicit, parseable, and separate from
  structural reuse.
4. **Separate architecture folders for models and studies** — Useful as a
  layout convention, but not sufficient as a role contract; markers still
  decide what is exportable.

## Consequences

- `pyssp_sysml2` must record part-def specialization and validate markers.
- A study cannot reuse model structure by inheritance; it composes the model
  with `part sut`.
- Export discovery can select `:> SspModel` definitions and skip `:> Study`
  definitions.
- Study compositions can be built and validated without producing an SSP.
- Existing architectures that use neither marker remain valid for the
  round-trip checker but are not eligible for the new export/study split.

**Trace**

Implements [PD-004](../../01-product/decisions/PD-004-sysml-sspmodel-authoring.md)
and [PD-006](../../01-product/decisions/PD-006-studies-consume-exported-ssps.md).
Authoring boundary: [ADR-007](ADR-007.md). Runtime application:
[ADR-010](ADR-010.md).

## Verification

None.

## Review Trigger

None.
