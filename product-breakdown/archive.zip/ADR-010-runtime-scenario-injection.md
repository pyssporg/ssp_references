---
id: ADR-010
title: Runtime Scenario and Experiment Application to Exported SSPs
summary: Studies apply SSV, SSM, and experiment data to a runtime copy of an exported SSP.
date: 2026-10-22
status: superseded
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - product-breakdown/03-implementation/workflow.md
  - scripts/run_simulations.py
supersedes: []
superseded_by: [ADR-013]
related: [ADR-008, ADR-009, DD-009, PD-006]
---

# ADR-010: Runtime Scenario and Experiment Application to Exported SSPs

## Context

`PD-006` separates an exported model SSP from the studies that exercise it. The
exported SSP has parameter connectors but no study-specific values. A study
supplies scenario values and experiment data. The simulation stage must combine
them without rebuilding or mutating the exported SSP.

Doing this per model would duplicate SSP XML editing in every build script and
hide engine-specific binding precedence.

## Decision

The runtime flow is:

```text
exported model SSP
      +
study scenario SSV + SSM
      +
study experiment descriptor
      ↓
pyssp_workflow.params / execute
      ↓
runtime SSP copy with a root-level ParameterBinding
      ↓
simulate backends
```

Rules:

- The exported SSP is never mutated.
- A study generates:
  - `<Scenario>.ssv` for parameter values;
  - `<Study>.ssm` for source → target mappings;
  - a study/experiment descriptor with window, step size, tolerance, and the
    base model name.
- `pyssp_workflow.params` resolves the scenario and mapping into one immutable
  record.
- `pyssp_workflow.execute` copies the exported SSP into a runtime workspace,
  adds the scenario SSV and a root-level `ParameterBinding` with the SSM
  mapping, and produces the simulation spec.
- Study binds are written against `sut.*`; the generated SSM targets are
  relative to the exported SSP root, so the `sut.` prefix is stripped.
- The study experiment descriptor drives the simulation window and tolerance.
  The exported SSP may still carry a default `experiments.xml` for standalone
  use, but studies do not depend on it.
- Result canonicalization strips every container name supplied by the runtime
  SSP, not just a single root name.

## Rationale

See Decision.

## Alternatives Considered

1. **Build one SSP per study** — Rejected: rebuilds per scenario and lets a
  study become an SSP.
2. **Bake a default scenario into the exported SSP** — Useful for standalone
  use, but insufficient for multiple studies and still requires rebuilds for
  new scenarios.
3. **Apply scenario data at runtime** — Accepted.
4. **Apply only SSV via engine-specific options** — Rejected: not portable
  across ssp4sim, OMSimulator, and FMPy.

## Consequences

- `pyssp_workflow` gains generic parameter-resolution and runtime-injection
  steps; `ssp_references` does not edit SSP XML itself.
- The registry and artifact layout distinguish a model build from a study case
  (see DD-009).
- Scenario SSV/SSM artifacts are standardized SSP XML and remain inspectable.
- Engines must honor root-level `ParameterBinding` precedence. This must be
  verified for all supported backends.
- The runtime archive must preserve unpacked FMU behavior and result
  canonicalization; both remain `pyssp_simulate` responsibilities.
- Scenario changes do not trigger SSP rebuilds.

**Trace**

Implements [PD-006](../../01-product/decisions/PD-006-studies-consume-exported-ssps.md).
Export rules: [ADR-009](ADR-009.md). Capability ownership:
[ADR-008](ADR-008.md).

## Verification

None.

## Review Trigger

None.
