---
id: ADR-011
title: Library Boundaries Use Standard Artifacts or Public API
summary: Library borders prefer standard artifacts; non-standard crossings use only documented public API types.
date: 2026-10-22
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - product-breakdown/00-intent/intent.md
  - product-breakdown/01-product/contract.md
  - product-breakdown/02-architecture/pipeline-boundaries.md
  - 3rd_party/pyssp_workflow/docs/breakdown/00-intent/intent.md
  - 3rd_party/pyssp_workflow/3rd_party/pyssp_vv/docs/breakdown/00-intent/intent.md
supersedes: []
superseded_by: []
related: [ADR-006]
---

# ADR-011: Library Boundaries Use Standard Artifacts or Public API

## Context

The ecosystem is split into independently versioned libraries. A border that
carries an internal object, an adapter-only structure, or an accidental export
turns one library's implementation detail into another library's compatibility
burden. Standard artifacts avoid that coupling where a file contract exists.
Some capabilities still need an in-process object, for example a trajectory,
verdict, simulation result, or runtime SSP handle.

## Decision

1. A library border prefers a standardized artifact: SSP, SSD, SSV, SSM,
   LS-REF, or result CSV.
2. If no standard covers the need, only a type that is explicitly part of the
   producer's public API may cross. It must be documented and importable from
   the producer's public surface.
3. Internal modules, private objects, and adapter-only structures never cross.
4. Adding a public type is a deliberate API decision, not an accidental export.

The rule applies to Python imports as well as files. It is recorded at the
intent and architecture layers of each project breakdown.

## Rationale

Standard artifacts keep tool versions independent. A public API fallback keeps
the remaining object crossings intentional, reviewable, and versioned instead
of accidental.

## Alternatives Considered

1. **Allow any importable object.** Rejected: importability is not an API
   promise, and it makes internal refactors breaking changes.
2. **Require standard artifacts for every crossing.** Rejected: some
   in-process capabilities (trajectories, verdicts, normalized results) have no
   standard file equivalent.
3. **Freeze all public types.** Rejected: the projects are still experimental;
   public API changes remain possible, but they are explicit decisions.

## Consequences

- A consumer must import the producer's public surface, not an internal module.
- A new public type needs documentation and a deliberate name.
- Existing internal imports are technical debt; they are fixed when touched or
  recorded as explicit exceptions where no public alternative exists.
- The breakdowns state the rule at intent/architecture level, not only in an
  implementation note.

## Verification

- Root and module breakdowns contain the rule at the intent/architecture layer.
- Boundary audits use the rule when reviewing new imports and artifacts.

## Review Trigger

Revisit if a project needs a new non-standard cross-border object.
