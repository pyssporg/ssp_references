---
id: ADR-012
title: pyssp_standard Comes From the Organization Experimental Fork
summary: The pinned `pyssp_standard` checkout is the organization's experimental fork, not the release line.
date: 2026-10-22
status: accepted
layers: [architecture, operation]
state: 02-architecture/pipeline-boundaries.md
artifacts:
  - 3rd_party/README.md
  - 3rd_party/pyssp_workflow/.gitmodules
supersedes: []
superseded_by: []
related: [ADR-005, AD-011]
---

# ADR-012: pyssp_standard Comes From the Organization Experimental Fork

## Context

Build stage needs `pyssp_standard` API upstream lacks: `package_archive`,
`LSRefExperiments`, `SSP.add_external_parameterset`. Personal fork
`jkCXf9X4/pyssp_standard` held them. Its `alpha` branch was 114 commits past
the fork `main`. Package metadata still said `0.8.2`. Consumers pinned the
fork by URL.

## Decision

Moved the checkout to `pyssporg/experimental_pyssp_standard`, a fork of
`pyssporg/pyssp_standard` owned by the organization. Repointed submodule URL,
docs, and the `pyfmi_me_to_cs` dependency. `alpha` is canonical, pin stays
detached. Metadata moved to `0.9.2.dev0`. PyPI publish workflow dropped.

## Rationale

Fork is superset experiment, not release line. Organization ownership keeps
upstream in reach and drops the personal-account dependency. Metadata stops
claiming a release the code left behind.

## Alternatives Considered

- Transfer the personal fork: blocked when the target holds a fork in the same
  network; keeps the personal-account surface.
- Rebase the fork onto upstream 0.9.1: large refactor; drops needed APIs.
- Branch inside `pyssporg/pyssp_standard`: puts a divergent refactor in the
  release repository.

## Consequences

- Positive: one organization-owned experiment; SHA pins keep resolving;
  honest version metadata.
- Negative: fork stays public; old personal fork objects stay in the fork
  network.
- Negative: new local patch in `pyssp_workflow` and `pyssp_sysml2`.

## Verification

`pb check --strict`. A fresh recursive clone resolves the submodule from the
new URL. `pytest` green in `pyssp_workflow` and `ssp_references`.

## Review Trigger

Revisit when the fork-only APIs land upstream and the experiment can retire.
