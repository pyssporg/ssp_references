---
id: ADR-013
title: SysML Authors Structure and Experiment; pyssp_standard Applies Parameter Form
summary: SysML defines wiring and the experiment; the fixture build applies the parameter form with pyssp_standard, including nested boundary wiring.
date: 2026-10-23
status: accepted
layers: [architecture]
state: 02-architecture/architecture.md
artifacts:
  - product-breakdown/02-architecture/architecture.md
  - product-breakdown/02-architecture/pipeline-boundaries.md
  - scripts/utils/authoring.py
supersedes: [ADR-010]
superseded_by: []
related: [ADR-009, PD-004, PD-007, DD-011]
---

# ADR-013: SysML Authors Structure and Experiment; pyssp_standard Applies Parameter Form

## Context

The SysML dialect expresses components, flat wiring, ports, and parameter sets.
It cannot express nested-system boundary connections, and study generation
standardizes one parameter form. The fixtures must keep several forms.

## Decision

`SspModel` authors components, wiring, and ports. `Study` authors the
experiment (start, stop, step) and scenario values. Each fixture's build applies
its parameter form with `pyssp_standard`; nested boundary connections are added
in the same step. Tolerance is not part of the experiment; it is read from the
FMU model descriptions.

## Rationale

Keeps wiring declarative and reviewable while retaining the forms the suite
tests. Boundary wiring that the dialect cannot express stays explicit.

## Alternatives Considered

- Extend the SysML dialect for nested boundary connections. Deferred.
- Flatten parameter forms to fit the generator. Rejected by PD-007.

## Consequences

- Positive: no hand-written SSD wiring in fixture sources.
- Negative: each form fixture carries a small build hook.

## Verification

`tests/test_sysml_fixtures.py` regenerates each SSD from SysML and asserts the
wiring and form.

## Review Trigger

Revisit when the dialect supports nested boundary connections and form
selection.
