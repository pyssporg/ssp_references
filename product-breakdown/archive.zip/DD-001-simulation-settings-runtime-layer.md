---
id: DD-001
title: Simulation Settings Belong to the Runtime Layer
summary: The simulation window and tolerance are frozen into `setup.json`; runtime reads `setup.json`, not `experiments.xml`.
date: 2026-10-22
status: accepted
layers: [implementation]
state: 03-implementation/workflow.md
artifacts:
  - scripts/run_simulations.py
  - product-breakdown/03-implementation/workflow.md
supersedes: []
superseded_by: []
related: [ADR-003, DD-009]
---

# DD-001: Simulation Settings Belong to the Runtime Layer

## Context

Early discussions considered using `experiments.xml` (from the LS-REF
convention) as the runtime configuration source for simulation dispatch.

## Decision

The simulation window is read from `experiments.xml` at setup time and frozen
into `setup.json`. The runtime layer (`run_simulations.py` and backend adapters)
reads from `setup.json`, not from `experiments.xml` directly.

## Rationale

Decouples the build pipeline (which produces SSPs with LS-REF metadata) from
the simulation pipeline (which needs a stable, flat configuration file). Keeps
`experiments.xml` as packaging metadata without making it the runtime contract.
Avoids re-parsing XML on every simulation dispatch.

## Alternatives Considered

None.

## Consequences

- `setup.json` must be regenerated if the experiment window or tolerance changes.
- The `experiments.xml` file must still be present and valid in each built SSP
  root because it is the source of truth at setup time.

**Trace**

Satisfies the runtime contract described in Section 5 of
[02-architecture/architecture.md](../../02-architecture/architecture.md).

**See Also**

- [ADR-003: Runtime Configuration Belongs to the Simulation Registry](../../02-architecture/decisions/ADR-003.md)
  — this ADR establishes the registry as the configuration source; DD-001
  specifies that the runtime layer consumes the frozen `setup.json` rather than
  `experiments.xml`.

**Amendment (2026-10-22): Study Descriptor Is the Setup Source**

For migrated fixtures, the window and tolerance are read from the study
descriptor instead of `experiments.xml`. The runtime still consumes only
`setup.json`. The exported SSP's `experiments.xml` is a standalone default and
is not required for a study run. See
[DD-009](./DD-009-runtime-scenario-injection.md).

## Verification

None.

## Review Trigger

None.
