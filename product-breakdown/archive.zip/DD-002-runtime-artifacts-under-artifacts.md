---
id: DD-002
title: Runtime Artifacts Stay Under `artifacts/`
summary: Runtime artifacts live under `artifacts/simulation/` and `artifacts/comparisons/`, separate from build outputs.
date: 2026-10-22
status: accepted
layers: [implementation]
state: 03-implementation/workflow.md
artifacts:
  - artifacts/simulation
  - artifacts/comparisons
supersedes: []
superseded_by: []
related: [ADR-001]
---

# DD-002: Runtime Artifacts Stay Under `artifacts/`

## Context

Simulation results could be stored next to each model's exported SSP under
`artifacts/models/<model>/<build>/`.

## Decision

Runtime artifacts live in `artifacts/simulation/<model>/<study>/` and
`artifacts/comparisons/<model>/<study>/`, completely separate from exported
model artifacts under `artifacts/models/` and study data under
`artifacts/studies/`.

## Rationale

Keeps build output immutable once produced. Simulation and comparison runs can
be cleaned or re-run without affecting the built SSPs. Prevents accidental
coupling between build logic and runtime configuration.

## Alternatives Considered

None.

## Consequences

- Four parallel directory trees under `artifacts/` (models, studies,
  simulation, comparisons).
- Cleanup must target each tree independently.
- Pipeline stages can be independently cleaned and re-run without rebuild.

**Trace**

Satisfies the pipeline stage isolation described in Section 1 of
[02-architecture/architecture.md](../../02-architecture/architecture.md).

**See Also**

- [ADR-001: Three-Stage Pipeline Architecture](../../02-architecture/decisions/ADR-001.md) — the pipeline
  structure that this artifact layout supports.

## Verification

None.

## Review Trigger

None.
