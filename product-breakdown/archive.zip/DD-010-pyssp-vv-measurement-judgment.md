---
id: DD-010
title: `pyssp_vv` Owns Comparison Measurement and Judgment
summary: Comparison metrics and verdicts come from pyssp_vv; this repo keeps registry and model policy.
date: 2026-10-22
status: accepted
layers: [implementation]
state: 03-implementation/workflow.md
artifacts:
  - scripts/utils/comparison.py
  - scripts/workflow/gate.py
  - scripts/workflow/model_policy.py
  - 3rd_party/pyssp_workflow/3rd_party/pyssp_vv/src/pyssp_vv/measure/alignment.py
supersedes: []
superseded_by: []
related: [DD-006, ADR-008]
---

# DD-010: `pyssp_vv` Owns Comparison Measurement and Judgment

## Context

The local comparison layer duplicated trajectory alignment, resampling, metric
families, shift search, and verdict logic that now live in `pyssp_vv`. It also
exposed only `pass` and `fail`, so a comparison that was not fit to judge could
not be reported as `invalid`.

## Decision

- `pyssp_vv.measure` produces comparisons, including the local-shift primitive.
- `pyssp_vv.judge` produces the verdict and reasons.
- This repository keeps registry policy, model signal invariants, and the
  manifest/CSV shape.
- `pass`, `fail`, and `invalid` are recorded distinctly. `invalid` dominates
  `fail` when a batch aggregates verdicts.

## Rationale

Measurement and judgment have different reasons to change. Keeping them in the
capability library lets other projects reuse the same contracts and prevents
this repository from drifting into a second V&V implementation.

## Alternatives Considered

None.

## Consequences

- Comparison metrics gain `coverage`, `shift_samples`, `normalisation`,
  `denominator`, and `normalised_max_abs_error` columns.
- Batch summaries can report `invalid`.
- `run_comparisons.py --fail-on-gate` treats both `fail` and `invalid` as
  non-passing.
- A degenerate reference signal is `invalid`, even when both engines agree on a
  constant value.

## Verification

- Root workflow tests cover `invalid` dominance.
- `pyssp_vv` tests cover the local-shift primitive.
- The pilot `signal_step_gain` pair and reference comparisons pass.

## Review Trigger

Revisit if `pyssp_vv` changes its metric or verdict contracts.
