---
id: DD-011
title: Build Packages the Study Scenario into the SSP
summary: The build emits a runnable SSP per model/study/build with the scenario applied; simulation runs it as-is.
date: 2026-10-23
status: accepted
layers: [implementation]
state: 03-implementation/workflow.md
artifacts:
  - product-breakdown/03-implementation/workflow.md
  - scripts/utils/authoring.py
  - scripts/workflow/registry.py
  - artifacts/simulation_registry.json
supersedes: [DD-009]
superseded_by: []
related: [ADR-013, PD-006, PD-002]
---

# DD-011: Build Packages the Study Scenario into the SSP

## Context

Runtime scenario injection forced one parameter form and kept a second runtime
path. Fixtures that need another form could not use the study path.

## Decision

Build derives the model SSP and the study artifacts, then packages the scenario
into the SSP in the fixture's form. Artifacts live at
`artifacts/models/<model>/<study>/<build>`. `study.json` carries window and
step. Simulation runs the built SSP with no injection. The registry resolves
study and build per case.

## Rationale

One runtime path, and the form is applied where it is known. The runtime does
not need to know about forms.

## Alternatives Considered

- Keep runtime injection. Rejected: it forces one form.
- Inject inline during simulation. Same limitation.

## Consequences

- Positive: simpler runtime; forms preserved.
- Negative: one build per study; a build output is mutated by design.

## Verification

`tests/test_sysml_fixtures.py` checks the layout, the descriptor, and each
form. `run_simulations.py` plus `run_comparisons.py` gate parity covers
behavior.

## Review Trigger

Revisit if one scenario-free SSP must serve many studies.
