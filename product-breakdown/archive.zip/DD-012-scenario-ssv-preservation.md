---
id: DD-012
title: Scenario Fixture Is Fully SysML-Authored With Its Legacy SSV
summary: The scenario model owns the six-member SSV and its live inline mapping; the study is experiment-only.
date: 2026-10-23
status: accepted
layers: [implementation]
state: 03-implementation/workflow.md
artifacts:
  - models/ssp/scenario/architecture/scenario.sysml
  - models/ssp/scenario/build.py
  - models/ssp/scenario/FIXTURE.md
  - models/fmu/scenario/fmu
  - tests/test_sysml_fixtures.py
  - artifacts/simulation_registry.json
supersedes: []
superseded_by: []
related: [AD-013, DD-011, IMP-101]
---

# DD-012: Scenario Fixture Is Fully SysML-Authored With Its Legacy SSV

## Context

The scenario fixture carried a checked-in SSD, a six-member SSV, and an SSM.
The SSV holds a multi-line string plus five unused start values. Four SSM
entries target components absent from the SSP.

## Decision

Author the model and the six-member `ScenarioSet` in SysML, applied inside
`System`. The exported model carries the SSV and an inline mapping; the study
is experiment-only. Keep only `scenario_input -> scenario.scenario_input`; do
not reproduce mappings to `ECS_HW` or `Consumer`, which do not exist in this
SSP.

## Rationale

One authored source, and the SSV stays member-for-member equivalent. The four
absent targets were already inert; preserving them would require phantom
components that change the SSP and break simulation.

## Alternatives Considered

- **Keep the checked-in SSV/SSM.** Rejected: the scenario has no SysML source.
- **Append the absent mappings in the build hook.** Rejected: keeps stale
  targets and hides them from the authored model.
- **Add phantom components.** Rejected: changes the SSP structure and breaks
  simulation.

## Consequences

- Positive: the SSV content is preserved; the duplicate root binding is gone.
- Negative: multi-target SSM coverage moves to
  `signal_nested_external_bindings`.
- Negative: SysML string literals now depend on `pyssp_sysml2` decoding `\n`,
  `\r`, and `\t`.

## Verification

`tests/test_sysml_fixtures.py` checks the six SSV members, the live mapping, and
one root binding. The migrated result CSV matches the pre-migration run: 10 001
rows, max abs diff `0.0`.

## Review Trigger

Revisit if this fixture must cover mappings to components outside its SSP.
