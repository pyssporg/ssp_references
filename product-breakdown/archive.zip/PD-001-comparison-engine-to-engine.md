---
id: PD-001
title: Comparison Methodology — Engine-to-Engine Only
summary: Comparison is pairwise engine-to-engine; no engine is the golden reference.
date: 2026-10-22
status: accepted
layers: [product]
state: 01-product/contract.md
artifacts:
  - scripts/run_comparisons.py
  - product-breakdown/04-verification/co_simulation_test_strategy.md
supersedes: []
superseded_by: []
related: [PD-003]
---

# PD-001: Comparison Methodology — Engine-to-Engine Only

## Context

The repository could compare simulation results against analytical expectations,
CSV baselines, or other engineered references. Early discussions considered
several comparison strategies.

## Decision

Comparison is always pairwise engine-to-engine. At least two distinct backend
runs are required. Baselines stored under `models/fmu/<model>/references/` are
used as fixture reference data, not as comparison targets in the pipeline.

## Rationale

Engine-to-engine comparison detects behavioral differences in the orchestration
layer without requiring analytical truth for every fixture. It keeps the
comparison pipeline symmetric and avoids maintaining engine-specific pass/fail
criteria for each model. Adding analytical truth would require per-fixture
mathematical analysis that is out of scope for a curated reference collection.

## Alternatives Considered

1. **Analytical truth comparison** — Each fixture would carry an analytical
   solution or reference CSV. Comparison would measure deviation from truth.
2. **Engine-to-engine comparison** — At least two distinct backend runs are
   required. Comparison measures pairwise deviation between backends.
3. **Hybrid** — Some fixtures use analytical truth, others use engine-to-engine.

## Consequences

- A single-backend run cannot be compared.
- Adding a new backend requires at least one other backend run for the
  comparison to produce results.
- Absolute correctness checks against analytical solutions are out of scope.

**Trace**

Satisfies the "Engine comparison results are the primary quality gate"
commitment in [00-intent/intent.md](../../00-intent/intent.md).

*This decision was migrated from the former design decisions log entry #2.*

**See Also**

- [PD-003: Supported Simulation Backends](./PD-003-supported-backends.md)
  establishes the engine set that makes engine-to-engine comparison possible.

## Verification

None.

## Review Trigger

None.
