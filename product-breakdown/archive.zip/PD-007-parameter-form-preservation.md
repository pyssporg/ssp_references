---
id: PD-007
title: Fixture Suite Preserves Parameter-Application Forms
summary: Reference fixtures keep the SSP parameter-application forms they exercise; authoring must not flatten them.
date: 2026-10-23
status: accepted
layers: [product]
state: 01-product/contract.md
artifacts:
  - product-breakdown/01-product/contract.md
  - models/ssp
  - scripts/utils/authoring.py
supersedes: []
superseded_by: []
related: [PD-004, PD-006, ADR-013]
---

# PD-007: Fixture Suite Preserves Parameter-Application Forms

## Context

Migrating fixtures to one SysML authoring path risked normalizing every
parameter application to a single form. The suite exists to exercise several
forms against engines, so that normalization would remove the tested aspect.

## Decision

The suite keeps the parameter forms it exercises: inline root, external
target-named, external with mapping, inline with external mapping, and nested
external. SysML authors structure and experiment; each fixture's build applies
its form with `pyssp_standard`. A fixture is not migrated if the transformation
would change the form it tests.

## Rationale

The product promise is engine validation against a representative range of SSP
patterns. Form variety is the fixture value, not an implementation detail.

## Alternatives Considered

- Standardize one form across the suite. Rejected: loses the tested aspect.
- Keep every fixture legacy. Rejected: retains hand-written wiring.

## Consequences

- Positive: form coverage is explicit and preserved.
- Negative: fixtures carry small build-specific form code.

## Verification

`tests/test_sysml_fixtures.py` asserts each migrated fixture's wiring and its
parameter form.

## Review Trigger

Revisit when `pyssp_sysml2` can express every used form directly.
